<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Csvreader {
    
    public function parse_file($file_path) {
        $file = fopen($file_path, 'r');
        $data = [];
        while (($row = fgetcsv($file)) !== FALSE) {
            $data[] = $row;
        }
        fclose($file);
        return $data;
    }
}