<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Role_model extends CI_Model {


    function insert_role($data)
    {
        $this->db->insert("role_tbl",$data);
        return $this->db->insert_id();
    }

    function select_role()
    {
        $this->db->order_by('role_tbl.id','DESC');
        $this->db->select("role_tbl.*");
        $this->db->from("role_tbl");
        $qry=$this->db->get();
        if($qry->num_rows()>0)
        {
            $result=$qry->result_array();
            return $result;
        }
    }

    function select_role_byID($id)
    {
        $this->db->where('role_tbl.id',$id);
        $this->db->select("role_tbl.*");
        $this->db->from("role_tbl");
        $qry=$this->db->get();
        if($qry->num_rows()>0)
        {
            $result=$qry->result_array();
            return $result;
        }
    }



    function delete_role($id)
    {
        $this->db->where('id', $id);
        $this->db->delete("role_tbl");
        $this->db->affected_rows();
    }

    
    function update_role($data,$id)
    {
        $this->db->where('id', $id);
        $this->db->update('role_tbl',$data);
        $this->db->affected_rows();
    }

    
    function select_roleaccess_byID($id)
    {
        $this->db->where('role_access_tbl.role_id',$id);
        $this->db->select("role_access_tbl.*,permission_tbl.name,permission_tbl.view_link,permission_tbl.add_link");
        $this->db->from("role_access_tbl");
        $this->db->join("permission_tbl",'permission_tbl.id=role_access_tbl.permission_id');
      
        $qry=$this->db->get();
        if($qry->num_rows()>0)
        {
            $result=$qry->result_array();
            return $result;
        }
    }

    
    




}
