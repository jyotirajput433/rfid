<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Gate_model extends CI_Model {


    function insert_gate($data)
    {
        $this->db->insert("gate_tbl",$data);
        return $this->db->insert_id();
    }

    function select_gate()
    {
        $qry=$this->db->get('gate_tbl');
        if($qry->num_rows()>0)
        {
            $result=$qry->result_array();
            return $result;
        }
    }

    function select_gate_byID($id)
    {

        $this->db->where('id',$id);
        $qry=$this->db->get('gate_tbl');
        if($qry->num_rows()>0)
        {
            $result=$qry->result_array();
            return $result;
        }
    }

    function delete_gate($id)
    {
        $this->db->where('id', $id);
        $this->db->delete("gate_tbl");
        $this->db->affected_rows();
    }

    

    function update_gate($data,$id)
    {
        $this->db->where('id', $id);
        $this->db->update('gate_tbl',$data);
        $this->db->affected_rows();
    }

    




}
