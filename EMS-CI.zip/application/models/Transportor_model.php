<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Transportor_model extends CI_Model {


    function insert_transportor($data)
    {
        $this->db->insert("transportor_tbl",$data);
        return $this->db->insert_id();
    }

    function select_transportor()
    {
        $this->db->order_by('transportor_tbl.id','DESC');
        $this->db->select("transportor_tbl.*");
        $this->db->from("transportor_tbl");
//        $this->db->join("vehicle_tbl",'vehicle_tbl.id=transportor_tbl.vehicle_id');
        $qry=$this->db->get();
        if($qry->num_rows()>0)
        {
            $result=$qry->result_array();
            return $result;
        }
    }

    function select_transportor_byID($id)
    {
        $this->db->where('transportor_tbl.id',$id);
       // $this->db->select("transportor_tbl.*,department_tbl.department_name");
        $this->db->select("*");
        $this->db->from("transportor_tbl");
       // $this->db->join("department_tbl",'department_tbl.id=staff_tbl.department_id');
        $qry=$this->db->get();
        if($qry->num_rows()>0)
        {
            $result=$qry->result_array();
            return $result;
        }
    }


    function delete_transportor($id)
    {
        $this->db->where('id', $id);
        $this->db->delete("transportor_tbl");
        $this->db->affected_rows();
    }

    
    function update_transportor($data,$id)
    {
        $this->db->where('id', $id);
        $this->db->update('transportor_tbl',$data);
        //echo $this->db->last_query(); die;
        $this->db->affected_rows();
    }

    

    
    




}
