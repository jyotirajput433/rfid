<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Policy_model extends CI_Model {


    function insert_policy($data)
    {
        $this->db->insert("policy_tbl",$data);
        return $this->db->insert_id();
    }

    function select_policy()
    {
        $this->db->order_by('policy_tbl.id','DESC');
        $this->db->select("policy_tbl.*");
        $this->db->from("policy_tbl");
      //  $this->db->join("department_tbl",'department_tbl.id=policy_tbl.department_id');
        $qry=$this->db->get();
        if($qry->num_rows()>0)
        {
            $result=$qry->result_array();
            return $result;
        }
    }

    function select_policy_byID($id)
    {
        $this->db->where('policy_tbl.id',$id);
        $this->db->select("policy_tbl.*");
        $this->db->from("policy_tbl");
//        $this->db->join("department_tbl",'department_tbl.id=policy_tbl.department_id');
        $qry=$this->db->get();
        if($qry->num_rows()>0)
        {
            $result=$qry->result_array();
            return $result;
        }
    }

    function select_policy_byEmail($email)
    {

        $this->db->where('email',$email);
        $qry=$this->db->get('policy_tbl');
        if($qry->num_rows()>0)
        {
            $result=$qry->result_array();
            return $result;
        }
    }

    function select_policy_byDept($dpt)
    {
        $this->db->where('policy_tbl.department_id',$dpt);
        $this->db->select("policy_tbl.*,department_tbl.department_name");
        $this->db->from("policy_tbl");
        $this->db->join("department_tbl",'department_tbl.id=policy_tbl.department_id');
        $qry=$this->db->get();
        if($qry->num_rows()>0)
        {
            $result=$qry->result_array();
            return $result;
        }
    }


    function delete_policy($id)
    {
        $this->db->where('id', $id);
        $this->db->delete("policy_tbl");
        $this->db->affected_rows();
    }

    
    function update_policy($data,$id)
    {
        $this->db->where('id', $id);
        $this->db->update('policy_tbl',$data);
        $this->db->affected_rows();
    }
}
