<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AccessLog_model extends CI_Model {


    function get_data()
    {
        $this->db->order_by('access_log_tbl.created_date','DESC');
        $this->db->select("gate_tbl.gate_name,access_log_tbl.created_date,rfid_tbl.rfid_value,transportor_tbl.name,vehicle_tbl.number");
        $this->db->from("access_log_tbl");
        $this->db->join("gate_tbl",'gate_tbl.id=access_log_tbl.gate',"LEFT");
        $this->db->join("rfid_tbl",'rfid_tbl.id=access_log_tbl.rfid',"LEFT");
        $this->db->join("vehicle_tbl",'vehicle_tbl.id=access_log_tbl.vehicle_id',"LEFT");
        $this->db->join("transportor_tbl",'transportor_tbl.id=access_log_tbl.owner',"LEFT");
        $this->db->limit(5);
        $qry=$this->db->get();
        if($qry->num_rows()>0)
        {
            $result=$qry->result_array();
            return $result;
        }
    }
    function get_Alldata($period,$start_date,$end_date)
    {
        $this->db->order_by('access_log_tbl.created_date','DESC');
        $this->db->select("gate_tbl.gate_name,access_log_tbl.created_date,rfid_tbl.rfid_value,transportor_tbl.name,vehicle_tbl.number");
        $this->db->from("access_log_tbl");
        $this->db->join("gate_tbl",'gate_tbl.id=access_log_tbl.gate',"LEFT");
        $this->db->join("rfid_tbl",'rfid_tbl.id=access_log_tbl.rfid',"LEFT");
        $this->db->join("vehicle_tbl",'vehicle_tbl.id=access_log_tbl.vehicle_id',"LEFT");
        $this->db->join("transportor_tbl",'transportor_tbl.id=access_log_tbl.owner',"LEFT");
        switch ($period) {
            case 'day':
                // Example query for day
                $this->db->where('access_log_tbl.created_date >=', $start_date);
                $this->db->where('access_log_tbl.created_date <=', $end_date);
                break;
            case 'week':
                $this->db->where('WEEK(access_log_tbl.created_date) = WEEK("'.$start_date.'")', NULL, FALSE);
                break;
            case 'month':
                $this->db->where('MONTH(access_log_tbl.created_date)', date('m', strtotime($start_date)));
                $this->db->where('YEAR(access_log_tbl.created_date)', date('Y', strtotime($start_date)));
                break;
            default:
                // Handle invalid period
                break;
        }
     
        $qry=$this->db->get();
        if($qry->num_rows()>0)
        {
            $result=$qry->result_array();
            return $result;
        }
    }
    function get_searchKeyData($keyword)
    {
        $this->db->order_by('access_log_tbl.created_date','DESC');
        $this->db->select("gate_tbl.gate_name,access_log_tbl.created_date,rfid_tbl.rfid_value,transportor_tbl.name,vehicle_tbl.number");
        $this->db->from("access_log_tbl");
        $this->db->join("gate_tbl",'gate_tbl.id=access_log_tbl.gate',"LEFT");
        $this->db->join("rfid_tbl",'rfid_tbl.id=access_log_tbl.rfid',"LEFT");
        $this->db->join("vehicle_tbl",'vehicle_tbl.id=access_log_tbl.vehicle_id',"LEFT");
        $this->db->join("transportor_tbl",'transportor_tbl.id=access_log_tbl.owner',"LEFT");
        $this->db->group_start();
$this->db->or_like('gate_tbl.gate_name', $keyword);
$this->db->or_like('access_log_tbl.created_date', $keyword);
$this->db->or_like('rfid_tbl.rfid_value', $keyword);
$this->db->or_like('transportor_tbl.name', $keyword);
$this->db->or_like('vehicle_tbl.number', $keyword);
$this->db->group_end();
        $qry=$this->db->get();
        if($qry->num_rows()>0)
        {
            $result=$qry->result_array();
            return $result;
        }
    }

    function get_searchResult($data)
    {
        $this->db->order_by('access_log_tbl.created_date','DESC');
        $this->db->select("gate_tbl.gate_name,access_log_tbl.created_date,rfid_tbl.rfid_value,transportor_tbl.name,vehicle_tbl.number");
        $this->db->from("access_log_tbl");
        $this->db->join("gate_tbl",'gate_tbl.id=access_log_tbl.gate',"LEFT");
        $this->db->join("rfid_tbl",'rfid_tbl.id=access_log_tbl.rfid',"LEFT");
        $this->db->join("vehicle_tbl",'vehicle_tbl.id=access_log_tbl.vehicle_id',"LEFT");
        $this->db->join("transportor_tbl",'transportor_tbl.id=access_log_tbl.owner',"LEFT");
        
        foreach ($data as $key => $value) {

            switch ($key) {
                case 'fromDate':
                    if (!empty($value)) {
                    $this->db->where('DATE(access_log_tbl.created_date) >=', date('Y-m-d', strtotime($value)));
                    }
                    break;
                case 'toDate':
                    if (!empty($value)) {
                    $this->db->where('DATE(access_log_tbl.created_date) <=', date('Y-m-d', strtotime($value)));
                    }
                    break;
                case 'fromTime':
                    // Assuming you have a separate column for time in the 'created_date' field
                    if (!empty($value)) {
                    $this->db->where('TIME(access_log_tbl.created_date) >=', $value);
                    }
                    break;
                case 'toTime':
                    // Assuming you have a separate column for time in the 'created_date' field
                    if (!empty($value)) {
                    $this->db->where('TIME(access_log_tbl.created_date) <=', $value);
                    }
                    break;
                case 'gate_id':
                    if (!empty($value)) {
                        $this->db->where('access_log_tbl.gate', $value);
                    }
                    break;
                case 'vehicle_type':
                    if (!empty($value)) {
                        $this->db->where('access_log_tbl.vehicle_type', $value);
                    }
                    break;
                case 'entry_type':
                    if (!empty($value)) {
                        $this->db->where('access_log_tbl.entry_type', $value);
                    }
                    break;
                case 'vehicle_number':
                    if (!empty($value)) {
                        $this->db->where('vehicle_tbl.vehicle_id', $value);
                    }
                    break;
                case 'transportor':
                    if (!empty($value)) {
                        $this->db->where('access_log_tbl.owner', $value);
                    }
                    break;
                default:
                $this->db->where('access_log_tbl.status',1);
                    break;
            }
        }
     
     
        $qry=$this->db->get();
        if($qry->num_rows()>0)
        {
            $result=$qry->result_array();
            return $result;
            
        }
    }

    function delete_department($id)
    {
        $this->db->where('id', $id);
        $this->db->delete("department_tbl");
        $this->db->affected_rows();
    }

    

    function update_department($data,$id)
    {
        $this->db->where('id', $id);
        $this->db->update('department_tbl',$data);
        $this->db->affected_rows();
    }

    




}
