<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Devicelist_model extends CI_Model {


    function insert_devicelist($data)
    {
            $this->db->insert("devicelist_tbl",$data);
        return $this->db->insert_id();
    }

    function select_devicelist()
    {
        $this->db->order_by('devicelist_tbl.id','DESC');
        $this->db->select("devicelist_tbl.*,gate_tbl.gate_name,device_tbl.device_name  ");
        $this->db->from("devicelist_tbl");
       $this->db->join("device_tbl",'device_tbl.id=devicelist_tbl.devicetype_id');
       $this->db->join("gate_tbl",'gate_tbl.id=devicelist_tbl.gate_id');
        $qry=$this->db->get();
        if($qry->num_rows()>0)
        {
            $result=$qry->result_array();
            return $result;
        }
    }

    function select_devicelist_byID($id)
    {
        $this->db->where('devicelist_tbl.id',$id);
       // $this->db->select("devicelist_tbl.*,department_tbl.department_name");
        $this->db->select("*");
        $this->db->from("devicelist_tbl");
       // $this->db->join("department_tbl",'department_tbl.id=staff_tbl.department_id');
        $qry=$this->db->get();
        if($qry->num_rows()>0)
        {
            $result=$qry->result_array();
            return $result;
        }
    }


    function delete_devicelist($id)
    {
        $this->db->where('id', $id);
        $this->db->delete("devicelist_tbl");
        $this->db->affected_rows();
    }

    
    function update_devicelist($data,$id)
    {
        $this->db->where('id', $id);
        $this->db->update('devicelist_tbl',$data);
        //echo $this->db->last_query(); die;
        $this->db->affected_rows();
    }

    

    
    




}
