<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Variation_model extends CI_Model {


    function insert_variation($data)
    {
        $this->db->insert("variation_tbl",$data);
        return $this->db->insert_id();
    }

    function select_variation()
    {
        $qry=$this->db->get('variation_tbl');
        if($qry->num_rows()>0)
        {
            $result=$qry->result_array();
            return $result;
        }
    }

    function select_variation_byID($id)
    {

        $this->db->where('id',$id);
        $qry=$this->db->get('variation_tbl');
        if($qry->num_rows()>0)
        {
            $result=$qry->result_array();
            return $result;
        }
    }

    function delete_variation($id)
    {
        $this->db->where('id', $id);
        $this->db->delete("variation_tbl");
        $this->db->affected_rows();
    }

    

    function update_variation($data,$id)
    {
        $this->db->where('id', $id);
        $this->db->update('variation_tbl',$data);
        $this->db->affected_rows();
    }

    




}
