<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Driver_model extends CI_Model {


    function insert_driver($data)
    {
        $this->db->insert("driver_tbl",$data);
        return $this->db->insert_id();
    }

    function select_driver()
    {
         $this->db->order_by('driver_tbl.id','DESC');
      //  $this->db->select("driver_tbl.*,department_tbl.department_name");
        $this->db->select("driver_tbl.*");

        $this->db->from("driver_tbl");
       // $this->db->join("department_tbl",'department_tbl.id=staff_tbl.department_id');
        $qry=$this->db->get();
        if($qry->num_rows()>0)
        {
            $result=$qry->result_array();
            return $result;
        }
    }

    function select_driver_byID($id)
    {
        $this->db->where('driver_tbl.id',$id);
       // $this->db->select("driver_tbl.*,department_tbl.department_name");
        $this->db->select("*");
        $this->db->from("driver_tbl");
       // $this->db->join("department_tbl",'department_tbl.id=staff_tbl.department_id');
        $qry=$this->db->get();
        if($qry->num_rows()>0)
        {
            $result=$qry->result_array();
            return $result;
        }
    }


    function delete_driver($id)
    {
        $this->db->where('id', $id);
        $this->db->delete("driver_tbl");
        $this->db->affected_rows();
    }

    
    function update_driver($data,$id)
    {
        $this->db->where('id', $id);
        $this->db->update('driver_tbl',$data);
        $this->db->affected_rows();
    }

    

    
    




}
