<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rfid_model extends CI_Model {


    function insert_rfid($data)
    {
        $this->db->insert("rfid_tbl",$data);
        return $this->db->insert_id();
    }

    function select_rfid()
    {
        $this->db->order_by('rfid_tbl.id','DESC');
        $this->db->select("rfid_tbl.*,vehicle_tbl.number");
        $this->db->from("rfid_tbl");
        $this->db->join("vehicle_tbl",'vehicle_tbl.id=rfid_tbl.vehicle_id','left');
        $qry=$this->db->get();
        if($qry->num_rows()>0)
        {
            $result=$qry->result_array();
            return $result;
        }
    }

    function get_token(){
        $this->db->order_by('rfid_tbl.token_no','DESC');
        $this->db->select("rfid_tbl.token_no");
        $this->db->from("rfid_tbl");
        $this->db->limit('1');
        
        $qry=$this->db->get();
        if($qry->num_rows()>0)
        {
            $result=$qry->result_array();
            return $result;
        }  
    }

    function is_token_exist($token){
        $this->db->select("rfid_tbl.*");
        $this->db->from("rfid_tbl");
        $this->db->where('token_no',$token);        
        $qry=$this->db->get();
        if($qry->num_rows()>0)
        {
            $result=$qry->result_array();
            return $result;
        }  
    }

    

    function select_rfid_byID($id)
    {
        $this->db->where('rfid_tbl.id',$id);
       // $this->db->select("rfid_tbl.*,department_tbl.department_name");
        $this->db->select("*");
        $this->db->from("rfid_tbl");
       // $this->db->join("department_tbl",'department_tbl.id=staff_tbl.department_id');
        $qry=$this->db->get();
        if($qry->num_rows()>0)
        {
            $result=$qry->result_array();
            return $result;
        }
    }


    function delete_rfid($id)
    {
        $this->db->where('id', $id);
        $this->db->delete("rfid_tbl");
        $this->db->affected_rows();
    }

    
    function update_rfid($data,$id)
    {
        $this->db->where('id', $id);
        $this->db->update('rfid_tbl',$data);
        $this->db->affected_rows();
    }

    

    
    




}
