<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Vehicle_model extends CI_Model {


    function insert_vehicle($data)
    {
        $this->db->insert("vehicle_tbl",$data);
        return $this->db->insert_id();
    }

    function select_vehicle()
    {
         $this->db->order_by('vehicle_tbl.id','DESC');
      //  $this->db->select("vehicle_tbl.*,department_tbl.department_name");
        $this->db->select("vehicle_tbl.*");

        $this->db->from("vehicle_tbl");
       // $this->db->join("department_tbl",'department_tbl.id=staff_tbl.department_id');
        $qry=$this->db->get();
        if($qry->num_rows()>0)
        {
            $result=$qry->result_array();
            return $result;
        }
    }

    function select_vehicle_byID($id)
    {
        $this->db->where('vehicle_tbl.id',$id);
       // $this->db->select("vehicle_tbl.*,department_tbl.department_name");
        $this->db->select("*");
        $this->db->from("vehicle_tbl");
       // $this->db->join("department_tbl",'department_tbl.id=staff_tbl.department_id');
        $qry=$this->db->get();
        if($qry->num_rows()>0)
        {
            $result=$qry->result_array();
            return $result;
        }
    }


    function delete_rfid($id)
    {
        $this->db->where('id', $id);
        $this->db->delete("vehicle_tbl");
        $this->db->affected_rows();
    }

    
    function update_rfid($data,$id)
    {
        $this->db->where('id', $id);
        $this->db->update('vehicle_tbl',$data);
        $this->db->affected_rows();
    }

    

    
    




}
