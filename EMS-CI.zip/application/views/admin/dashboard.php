  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
     
      <div class="row">
      <div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-body">
						<div class="pull-right">
							
              <div  class="pull-left">
              <form id="SearchForm">
                <input type="text" placeholder="Search.." required name="quicksearchKeyWord" id="quicksearchKeyWord">
                <input type="submit" value="Submit">
               
              </form>
              </div>
              <div class="btn-group">
								<button type="button" class="btn btn-warning btn-filter" data-toggle="modal" data-target="#exampleModal">Advance Search</button>
						  </div>
					  </div>
            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                <form id="quickSearchForm">
                <!-- <div class="form-group col-sm-6 col-xs-6">
                  <input type="text" class="form-control" id="quickSearchInput" name="query" placeholder="Enter search query">
                </div> -->
                <div class="form-group col-sm-6 col-xs-6">
                  <input type="date" class="form-control" id="fromDate" name="fromDate">
                </div>
                <div class="form-group col-sm-6 col-xs-6">
                  <input type="date" class="form-control" id="toDate" name="toDate">
                </div>
                <div class="form-group col-sm-6 col-xs-6">
                  <input type="time" class="form-control" id="fromTime" name="fromTime">
                </div>
                <div class="form-group col-sm-6 col-xs-6">
                  <input type="time" class="form-control" id="" name="toTime">
                </div>


                <div class="form-group col-sm-6 col-xs-6">
                  <select class="form-control" name="gate_id">
                    <option value="">Select Gate</option>
                    <?php
                    if(isset($gate))
                    {
                      foreach($gate as $cnt1)
                      {
                        if($cnt1['id']==$cnt['gate_name'])
                        {    
                          print "<option value='".$cnt1['id']."' selected>".$cnt1['gate_name']."</option>";
                        }
                        else{
                          print "<option value='".$cnt1['id']."'>".$cnt1['gate_name']."</option>";
                        }
                      }
                    } 
                    ?>
                  </select>
                </div>


                <div class="form-group col-sm-6 col-xs-6">
                  <select class="form-control" name="vehicle_type">
                    <option value="">Select</option>
                    <?php
                    if(isset($vehicleType))
                    {
                      foreach($vehicleType as $cnt1)
                      {
                        if($cnt1['id']==$cnt['vehicle_type'])
                        {    
                          print "<option value='".$cnt1['id']."' selected>".$cnt1['vehicle_name']."</option>";
                        }
                        else{
                          print "<option value='".$cnt1['id']."'>".$cnt1['vehicle_name']."</option>";
                        }
                      }
                    } 
                    ?>
                  </select>
                </div>
                
                <div class="form-group col-sm-6 col-xs-6">
                  <select class="form-control" name="entry_type" id="entry_type">
                    <option value="">Select Entry Type</option>
                    <option value="1">In</option>";
                    <option value="2">Out</option>";
                  </select>
                </div>

                <div class="form-group col-sm-6 col-xs-6">
                  <select class="form-control" name="vehicle_type">
                    <option value="">Select Registration Type</option>
                    <?php
                    if(isset($vehicle))
                    {
                      foreach($vehicle as $cnt1)
                      {
                        if($cnt1['id']==$cnt['number'])
                        {    
                          print "<option value='".$cnt1['id']."' selected>".$cnt1['number']."</option>";
                        }
                        else{
                          print "<option value='".$cnt1['id']."'>".$cnt1['number']."</option>";
                        }
                      }
                    } 
                    ?>
                  </select>
                </div>

                <div class="form-group col-sm-6 col-xs-6">
                  <select class="form-control" name="transportor" id="transportor">
                    <option value="">Select Owner</option>
                    <?php
                    if(isset($transportor))
                    {
                      foreach($transportor as $cnt1)
                      {
                        if($cnt1['id']==$cnt['name'])
                        {    
                          print "<option value='".$cnt1['id']."' selected>".$cnt1['name']."</option>";
                        }
                        else{
                          print "<option value='".$cnt1['id']."'>".$cnt1['name']."</option>";
                        }
                      }
                    } 
                    ?>
                  </select>
                </div>

                <div class="form-group col-sm-6 col-xs-6">
                  <select class="form-control" name="vehicle_id">
                    <option value="">Select</option>
                    <?php
                    if(isset($vehicle))
                    {
                      foreach($vehicle as $cnt1)
                      {
                        if($cnt1['id']==$cnt['number'])
                        {    
                          print "<option value='".$cnt1['id']."' selected>".$cnt1['number']."</option>";
                        }
                        else{
                          print "<option value='".$cnt1['id']."'>".$cnt1['number']."</option>";
                        }
                      }
                    } 
                    ?>
                  </select>
                </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
                </form>
              </div>
            </div>
          </div>
						<div class="table-container"  id="dailyRecord">
            <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item active">
                        <a class="nav-link active" data-toggle="tab" href="#day">Day</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#week">Week</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#month">Month</a>
                    </li>
            </ul>
              <!-- Tab panes -->
             


              <div class="tab-content">
                  <div id="day" class="tab-pane active"><br>
                      <!-- Table for day data will be loaded here -->
                      <table id="dayTable" class="table table-filter">
                          <thead>
                              <tr>
                                  <th>Sl No</th>
                                  <th>RFID</th>
                                  <th>Date</th>
                                  <th>Gate</th>
                                  <th>Owner</th>
                                  <th>Vehicle</th>
                              </tr>
                          </thead>
                          <tbody>
                              <!-- Table rows for day data will be loaded here -->
                          </tbody>
                      </table>
                  </div>
                  <div id="week" class="tab-pane fade"><br>
                      <!-- Table for week data will be loaded here -->
                      <table id="weekTable" class="table table-filter">
                      <thead>
                              <tr>
                                  <th>Sl No</th>
                                  <th>RFID</th>
                                  <th>Date</th>
                                  <th>Gate</th>
                                  <th>Owner</th>
                                  <th>Vehicle</th>
                              </tr>
                          </thead>
                          <tbody>
                              <!-- Table rows for day data will be loaded here -->
                          </tbody>
  
                      </table>
                  </div>
                  <div id="month" class="tab-pane fade"><br>
                      <!-- Table for month data will be loaded here -->
                      <table id="monthTable" class="table table-filter">
                      <thead>
                              <tr>
                                  <th>Sl No</th>
                                  <th>RFID</th>
                                  <th>Date</th>
                                  <th>Gate</th>
                                  <th>Owner</th>
                                  <th>Vehicle</th>
                              </tr>
                          </thead>
                          <tbody>
                              <!-- Table rows for day data will be loaded here -->
                          </tbody>
                          </table>
                  </div>
              </div>
						
					</div>



          <div class="table-container" id="quickSearchDiv" style="display: none;">
          <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active"  href="<?php echo base_url('/');?>">Back</a>
                    </li>
          </ul>
          <div class="tab-content" >
                  <div id="day" class="tab-pane active"><br>
                      <!-- Table for day data will be loaded here -->
                      <table id="quickSearchTable" class="table table-filter">
                          <thead>
                              <tr>
                                  <th>Sl No</th>
                                  <th>RFID</th>
                                  <th>Date</th>
                                  <th>Gate</th>
                                  <th>Owner</th>
                                  <th>Vehicle</th>
                              </tr>
                          </thead>
                          <tbody>
                              <!-- Table rows for day data will be loaded here -->
                          </tbody>
                      </table>
                  </div>
              
              </div>
          </div>
				</div>
        </div></div>
			
      </div>
      <div class="row">
      <div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-body">
						<div class="table-container">
							<table class="table table-filter" id="dashboard">
                <thead>
                  <tr>
                      <th>Sl No</th>
                      <th>RFID</th>
                      <th>Date</th>
                      <th>Gate</th>
                      <th>Owner</th>
                      <th>Vehicle</th>
                  </tr>
                </thead>
                <tbody>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
      </div>


      <div class="row">

<?php if($this->session->flashdata('success')): ?>
  <div class="col-md-12">
    <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
          <h4><i class="icon fa fa-check"></i> Success!</h4>
          <?php echo $this->session->flashdata('success'); ?>
    </div>
  </div>
<?php elseif($this->session->flashdata('error')):?>
<div class="col-md-12">
    <div class="alert alert-danger alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
          <h4><i class="icon fa fa-check"></i> Failed!</h4>
          <?php echo $this->session->flashdata('error'); ?>
    </div>
  </div>
<?php endif;?>

       
<!-- /.col -->
</div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
