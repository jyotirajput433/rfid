<style>
  .floatybox {
     display: inline-block;
     width: 123px;
}
  </style>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Staff Management
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Staff Management</a></li>
        <li class="active">Edit Staff</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">

        <?php echo validation_errors('<div class="col-md-12">
            <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4><i class="icon fa fa-check"></i> Failed!</h4>', '</div>
          </div>'); ?>

        <?php if($this->session->flashdata('success')): ?>
          <div class="col-md-12">
            <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4><i class="icon fa fa-check"></i> Success!</h4>
                  <?php echo $this->session->flashdata('success'); ?>
            </div>
          </div>
        <?php elseif($this->session->flashdata('error')):?>
        <div class="col-md-12">
            <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4><i class="icon fa fa-check"></i> Failed!</h4>
                  <?php echo $this->session->flashdata('error'); ?>
            </div>
          </div>
        <?php endif;?>

        <!-- column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Edit Vehicle</h3>
            </div>
            <!-- /.box-header -->

            <?php if(isset($content)): ?>
              <?php foreach($content as $cnt): ?>
                  <!-- form start -->
                  <?php echo form_open_multipart('Vehicle/insert');?>
              <div class="box-body">
              <div class="col-md-6">
                  <div class="form-group">
                    <label>Vehicle</label>
                    <select class="form-control" name="vehicle_type">
                      <option value="">Select</option>
                      <?php
                      if(isset($vehicleType))
                      {
                        foreach($vehicleType as $cnt1)
                        {
                       //   print "<option value='".$cnt['id']."'>".$cnt['vehicle_name']."</option>";
                       if($cnt1['id']==$cnt['vehicle_type'])
                       {    
                         print "<option value='".$cnt1['id']."' selected>".$cnt1['vehicle_name']."</option>";
                       }
                       else{
                         print "<option value='".$cnt1['id']."'>".$cnt1['vehicle_name']."</option>";
                       }
                    }
                      } 
                      ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-6">
                <div class="form-group">
                    <label>Vehicle Number</label>
                    <input type="text" name="number" class="form-control"  value="<?php echo $cnt['number']; ?>">
                  </div>
                </div>

                <div class="col-md-6">
                <div class="form-group">
                    <label>Color</label>
                    <input type="text" name="color" class="form-control"  value="<?php echo $cnt['color']; ?>">
                  </div>
                </div>

                <div class="col-md-6">
                <div class="form-group">
                    <label>Model</label>
                    <input type="text" name="model" class="form-control"  value="<?php echo $cnt['model']; ?>">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Photo</label>
                    <input type="file" name="vehiclephoto" class="form-control">
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="form-group">
                    <label>RFID Tag</label>
                    <select class="form-control" name="rfid_tag">
                      <option value="">Select RFID</option>
                      <?php
                      if(isset($rfid))
                      {
                        foreach($rfid as $cnt1)
                        {
                    //      print "<option value='".$cnt['id']."'>".$cnt['rfid_value']."</option>";
                    if($cnt1['id']==$cnt['rfid_tag'])
                    {    
                      print "<option value='".$cnt1['id']."' selected>".$cnt1['rfid_value']."</option>";
                    }
                    else{
                      print "<option value='".$cnt1['id']."'>".$cnt1['rfid_value']."</option>";
                    }
                 }
                      } 
                      ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="form-group">
                    <label>Vehicle Policy</label>
                    <select class="form-control" name="vehicle_policy">
                      <option value="">Select Policy</option>
                      <?php
                      if(isset($policy))
                      {
                        foreach($policy as $cnt1)
                        {
                            if($cnt1['id']==$cnt['vehicle_policy'])
                    {    
                      print "<option value='".$cnt1['id']."' selected>".$cnt1['policy_name']."</option>";
                    }
                    else{
                      print "<option value='".$cnt1['id']."'>".$cnt1['policy_name']."</option>";
                    }
                           //print "<option value='".$cnt['id']."'>".$cnt['policy_name']."</option>";
                        }
                      } 
                      ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="form-group">
                    <label>Is Allowed</label>
                    <select class="form-control" name="is_allowed">
                      <option value="">Select</option>
                      <option <?php if($cnt['is_allowed'] == 1){ echo 'selected';} ?>value="1">Yes</option>
                      <option <?php if($cnt['is_allowed'] == 0){ echo 'selected';} ?>value="0">No</option>
                    </select>
                  </div>
                </div>

                <div class="col-md-6">
                <div class="form-group">
                    <label>Permit Valid Till Date</label>
                    <input type="date" name="parmit_valid_till" class="form-control"  value="<?php echo $cnt['permit_valid_till']; ?>">
                  </div>
                </div>

                
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Owner</label>
                    <select class="form-control" name="owner">
                      <option value="">Select Owner</option>
                      <?php
                      if(isset($transportor))
                      {
                        foreach($transportor as $cnt1)
                        {
                          if($cnt1['id']==$cnt['owner'])
                    {    
                      print "<option value='".$cnt1['id']."' selected>".$cnt1['name']."</option>";
                    }
                    else{
                      print "<option value='".$cnt1['id']."'>".$cnt1['name']."</option>";
                    }
                  }
                      } 
                      ?>
                    </select>
                  </div>
                </div>


                
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Driver</label>
                    <select class="form-control" name="driver_id">
                      <option value="">Select Driver</option>
                      <?php
                      if(isset($driver))
                      {
                        foreach($driver as $cnt1)
                        {
                          if($cnt1['id']==$cnt['driver_id'])
                          {    
                            print "<option value='".$cnt1['id']."' selected>".$cnt1['driver_name']."</option>";
                          }
                          else{
                           
                          print "<option value='".$cnt1['id']."'>".$cnt1['driver_name']."</option>";
                          }                        }
                      } 
                      ?>
                    </select>
                  </div>
                </div>


                <div class="col-md-6">
                  <div class="form-group">
                    <label>Is Valid</label>
                    <select class="form-control" name="is_valid">
                      <option value="">Select</option>
                      <option value="1" <?php if($cnt['is_allowed'] == 1){ echo 'selected';} ?>>Yes</option>
                      <option value="0" <?php if($cnt['is_allowed'] == 0){ echo 'selected';} ?>>No</option>
                    </select>
                  </div>
                </div>


                <!-- <div class="col-md-6">
                  <div class="form-group">
                    <label>Vehicle</label>
                    <select class="form-control" name="slcvehicle">
                      <option value="">Select</option>
                      <?php
                      if(isset($vehicle))
                      {
                        foreach($vehicle as $cnt1)
                        {
                          if($cnt1['id']==$cnt['driver_id'])
                          {    
                            print "<option value='".$cnt1['id']."' selected>".$cnt1['vehicle_name']."</option>";
                          }
                          else{
                           
                            print "<option value='".$cnt1['id']."'>".$cnt1['vehicle_name']."</option>";
                          } 
                        }
                      } 
                      ?>
                    </select>
                  </div>
                </div> -->
                 
                
              </div>    
                    <!-- /.box-body -->
                    <div class="box-footer">
                      <button type="submit" class="btn btn-success pull-right">Submit</button>
                    </div>
                  </form>
                <?php endforeach; ?>
            <?php endif; ?>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->