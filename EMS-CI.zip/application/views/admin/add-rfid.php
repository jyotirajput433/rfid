  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        RFID Management
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">RFID Management</a></li>
        <li class="active">Add RFID</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">

        <?php echo validation_errors('<div class="col-md-12">
            <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4><i class="icon fa fa-check"></i> Failed!</h4>', '</div>
          </div>'); ?>

        <?php if($this->session->flashdata('success')): ?>
          <div class="col-md-12">
            <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4><i class="icon fa fa-check"></i> Success!</h4>
                  <?php echo $this->session->flashdata('success'); ?>
            </div>
          </div>
        <?php elseif($this->session->flashdata('error')):?>
        <div class="col-md-12">
            <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4><i class="icon fa fa-check"></i> Failed!</h4>
                  <?php echo $this->session->flashdata('error'); ?>
            </div>
          </div>
        <?php endif;?>

        <!-- column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Add RFID</h3>
              <div class="btn-group pull-right">
								<button type="button" class="btn btn-warning btn-filter" data-toggle="modal" data-target="#exampleModal">Bulk Upload</button>
						  </div></div>

            
        <!-- model start -->
            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Upload Data</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                <form action="<?= base_url('Rfid/upload_csv') ?>" method="post" enctype="multipart/form-data">
              
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Token No</label>
                    <input type="number" name="token_start" class="form-control" placeholder="Token No">
                </div>
                </div>

                <div class="col-md-6">
                <div class="form-group">
                    <label>RFID value</label>
                    <input type="file" name="csv_file" class="form-control">
                </div>
                </div>
                <button type="submit" class="btn btn-success pull-right">Upload CSV</button>
             
                </form>

                </div>
                <div class="modal-footer">
                </div>
               
              </div>
            </div>
          </div>

            <!-- /.box-header -->
            <!-- form start -->
            <?php echo form_open_multipart('Rfid/insert');?>
              <div class="box-body">
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Token No</label>
                    <input type="text" name="token_no" class="form-control" readonly value="<?php echo $get_last_token['0']['token_no'] +1;?>">
                  </div>
                </div>

                <div class="col-md-6">
                <div class="form-group">
                    <label>RFID value</label>
                    <input type="text" name="rfid_value" class="form-control" placeholder="RFID Value">
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="form-group">
                    <label>Is It Valid RFID</label>
                    <select class="form-control" name="is_valid">
                      <option value="">Select</option>
                      <option value="1" selected>Yes</option>
                      <option value="0">No</option>
                    </select>
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="form-group">
                    <label>Is Allocated</label>
                    <select class="form-control" name="is_allocated">
                      <option value="">Select</option>
                      <option value="1" selected>Yes</option>
                      <option value="0">No</option>
                    </select>
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="form-group">
                    <label>Is Lost</label>
                    <select class="form-control" name="is_lost">
                      <option value="">Select</option>
                      <option value="1" selected>Yes</option>
                      <option value="0">No</option>
                    </select>
                  </div>
                </div>

                
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Vehicle</label>
                    <select class="form-control" name="slcvehicle">
                      <option value="">Select Vehicle</option>
                      <?php
                      if(isset($vehicle))
                      {
                        foreach($vehicle as $cnt)
                        {
                          print "<option value='".$cnt['id']."'>".$cnt['number']."</option>";
                        }
                      } 
                      ?>
                    </select>
                  </div>
                </div>
                 
                
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="submit" class="btn btn-success pull-right">Submit</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->