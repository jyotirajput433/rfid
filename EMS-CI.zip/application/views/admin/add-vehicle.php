  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Vehicle Management
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Vehicle Management</a></li>
        <li class="active">Add Vehicle</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">

        <?php echo validation_errors('<div class="col-md-12">
            <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4><i class="icon fa fa-check"></i> Failed!</h4>', '</div>
          </div>'); ?>

        <?php if($this->session->flashdata('success')): ?>
          <div class="col-md-12">
            <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4><i class="icon fa fa-check"></i> Success!</h4>
                  <?php echo $this->session->flashdata('success'); ?>
            </div>
          </div>
        <?php elseif($this->session->flashdata('error')):?>
        <div class="col-md-12">
            <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4><i class="icon fa fa-check"></i> Failed!</h4>
                  <?php echo $this->session->flashdata('error'); ?>
            </div>
          </div>
        <?php endif;?>

        <!-- column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Add Vehicle</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <?php echo form_open_multipart('Vehicle/insert');?>
              <div class="box-body">
              <div class="col-md-6">
                  <div class="form-group">
                    <label>Vehicle Type</label>
                    <select class="form-control" name="vehicle_type">
                      <option value="">Select Vehicle Type</option>
                        <?php
                        if(isset($vehicleType))
                        {
                          foreach($vehicleType as $cnt)
                          {
                            print "<option value='".$cnt['id']."'>".$cnt['vehicle_name']."</option>";
                          }
                        } 
                        ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-6">
                <div class="form-group">
                    <label>Vehicle Number</label>
                    <input type="text" name="number" class="form-control" placeholder="Vehicle Number">
                  </div>
                </div>

                <div class="col-md-6">
                <div class="form-group">
                    <label>Color</label>
                    <input type="text" name="color" class="form-control" placeholder="Color">
                  </div>
                </div>

                <div class="col-md-6">
                <div class="form-group">
                    <label>Model</label>
                    <input type="text" name="model" class="form-control" placeholder="Model">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Photo</label>
                    <input type="file" name="vehiclephoto" class="form-control">
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="form-group">
                    <label>RFID Tag</label>
                    <select class="form-control" name="rfid_tag">
                      <option value="">Select RFID</option>
                      <?php
                      if(isset($rfid))
                      {
                        foreach($rfid as $cnt)
                        {
                          print "<option value='".$cnt['id']."'>".$cnt['rfid_value']."</option>";
                        }
                      } 
                      ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="form-group">
                    <label>Vehicle Policy</label>
                    <select class="form-control" name="vehicle_policy">
                      <option value="">Select Policy</option>
                      <?php
                      if(isset($policy))
                      {
                        foreach($policy as $cnt)
                        {
                          print "<option value='".$cnt['id']."'>".$cnt['policy_name']."</option>";
                        }
                      } 
                      ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="form-group">
                    <label>Is Allowed</label>
                    <select class="form-control" name="is_allowed">
                      <option value="">Select</option>
                      <option value="1" selected>Yes</option>
                      <option value="0">No</option>
                    </select>
                  </div>
                </div>

                <div class="col-md-6">
                <div class="form-group">
                    <label>Permit Valid Till Date</label>
                    <input type="date" name="parmit_valid_till" class="form-control" >
                  </div>
                </div>

                
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Owner</label>
                    <select class="form-control" name="owner">
                      <option value="">Select Owner</option>
                      <?php
                      if(isset($transportor))
                      {
                        foreach($transportor as $cnt)
                        {
                          print "<option value='".$cnt['id']."'>".$cnt['name']."</option>";
                        }
                      } 
                      ?>
                    </select>
                  </div>
                </div>


                
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Driver</label>
                    <select class="form-control" name="driver_id">
                      <option value="">Select Driver</option>
                      <?php
                      if(isset($driver))
                      {
                        foreach($driver as $cnt)
                        {
                          print "<option value='".$cnt['id']."'>".$cnt['driver_name']."</option>";
                        }
                      } 
                      ?>
                    </select>
                  </div>
                </div>


                <div class="col-md-6">
                  <div class="form-group">
                    <label>Is Valid</label>
                    <select class="form-control" name="is_valid">
                      <option value="">Select</option>
                      <option value="1" selected>Yes</option>
                      <option value="0">No</option>
                    </select>
                  </div>
                </div>


                <!-- <div class="col-md-6">
                  <div class="form-group">
                    <label>Vehicle</label>
                    <select class="form-control" name="slcvehicle">
                      <option value="">Select</option>
                      <?php
                      if(isset($vehicle))
                      {
                        foreach($vehicle as $cnt)
                        {
                          print "<option value='".$cnt['id']."'>".$cnt['vehicle_name']."</option>";
                        }
                      } 
                      ?>
                    </select>
                  </div>
                </div> -->
                 
                
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="submit" class="btn btn-success pull-right">Submit</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->