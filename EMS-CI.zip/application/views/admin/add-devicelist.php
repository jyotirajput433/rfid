  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Device List Management
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Device List Management</a></li>
        <li class="active">Add Device List</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">

        <?php echo validation_errors('<div class="col-md-12">
            <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4><i class="icon fa fa-check"></i> Failed!</h4>', '</div>
          </div>'); ?>

        <?php if($this->session->flashdata('success')): ?>
          <div class="col-md-12">
            <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4><i class="icon fa fa-check"></i> Success!</h4>
                  <?php echo $this->session->flashdata('success'); ?>
            </div>
          </div>
        <?php elseif($this->session->flashdata('error')):?>
        <div class="col-md-12">
            <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4><i class="icon fa fa-check"></i> Failed!</h4>
                  <?php echo $this->session->flashdata('error'); ?>
            </div>
          </div>
        <?php endif;?>

        <!-- column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Add Device List</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <?php echo form_open_multipart('devicelist/insert');?>
              <div class="box-body">
                <div class="col-md-6">
                  <div class="form-group">
                    <label>IP-Address</label>
                    <input type="text" name="ip_address" class="form-control" placeholder="IP Address">
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="form-group">
                    <label>Device Type</label>
                    <select class="form-control" name="slcdevice">
                      <option value="">Select Device Type</option>
                      <?php
                      if(isset($deviceType))
                      {
                        foreach($deviceType as $cnt)
                        {
                          print "<option value='".$cnt['id']."'>".$cnt['device_name']."</option>";
                        }
                      } 
                      ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="form-group">
                    <label>Gate</label>
                    <select class="form-control" name="slcgate">
                      <option value="">Select Gate</option>
                      <?php
                      if(isset($gate))
                      {
                        foreach($gate as $cnt)
                        {
                          print "<option value='".$cnt['id']."'>".$cnt['gate_name']."</option>";
                        }
                      } 
                      ?>
                    </select>
                  </div>
                </div>      


                <div class="col-md-6">
                <div class="form-group">
                    <label>Direction</label>
                    <input type="text" name="direction" class="form-control" placeholder="Direction">
                  </div>
                </div>

                <div class="col-md-6">
                <div class="form-group">
                    <label>MAC Address</label>
                    <input type="text" name="mac_address" class="form-control" placeholder="MAC Address">
                  </div>
                </div>

                <div class="col-md-6">
                <div class="form-group">
                    <label>Make</label>
                    <input type="text" name="make" class="form-control" placeholder="Make">
                  </div>
                </div>

                <div class="col-md-6">
                <div class="form-group">
                    <label>Model</label>
                    <input type="text" name="model" class="form-control" placeholder="Model">
                  </div>
                </div>

                

                <div class="col-md-6">
                <div class="form-group">
                    <label>URL</label>
                    <input type="text" name="url" class="form-control" placeholder="URL">
                  </div>
                </div>
                
                 
                
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="submit" class="btn btn-success pull-right">Submit</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->