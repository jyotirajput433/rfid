  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        RFIDs
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">RFIDs</a></li>
        <li class="active">Edit RFID</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">

        <?php if($this->session->flashdata('success')): ?>
          <div class="col-md-12">
            <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4><i class="icon fa fa-check"></i> Success!</h4>
                  <?php echo $this->session->flashdata('success'); ?>
            </div>
          </div>
        <?php elseif($this->session->flashdata('error')):?>
        <div class="col-md-12">
            <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4><i class="icon fa fa-check"></i> Failed!</h4>
                  <?php echo $this->session->flashdata('error'); ?>
            </div>
          </div>
        <?php endif;?>

        <!-- column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Edit RFID</h3>
            </div>
            <!-- /.box-header -->

            <?php if(isset($content)): ?>
              <?php foreach($content as $cnt): ?>
                <!-- form start -->
                <form role="form" action="<?php echo base_url(); ?>update-rfid" method="POST">
                <div class="box-body">
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Token No</label>
                    <input type="hidden" name="txtid" value="<?php echo $cnt['id']; ?>" class="form-control">
                    <input type="text" name="token_no" readonly value="<?php echo $cnt['token_no']; ?>" class="form-control" placeholder="Token No">
                  </div>
                </div>

                <div class="col-md-6">
                <div class="form-group">
                    <label>RFID value</label>
                    <input type="text" name="rfid_value" class="form-control" value="<?php echo $cnt['rfid_value']; ?>" placeholder="RFID Value">
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="form-group">
                    <label>Is It Valid RFID</label>
                    <select class="form-control" name="is_valid">
                      <option value="">Select</option>
                      <option value="1" <?php if($cnt['is_valid'] == 1){echo 'selected';} ?> >Yes</option>
                      <option value="0" <?php if($cnt['is_valid'] == 0){echo 'selected';} ?>>No</option>
                    </select>
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="form-group">
                    <label>Is Allocated</label>
                    <select class="form-control" name="is_allocated">
                      <option value="">Select</option>
                      <option value="1" <?php if($cnt['is_allocated'] == 1){echo 'selected';} ?>>Yes</option>
                      <option value="0" <?php if($cnt['is_allocated'] == 1){echo 'selected';} ?>>No</option>
                    </select>
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="form-group">
                    <label>Is Lost</label>
                    <select class="form-control" name="is_lost">
                      <option value="">Select</option>
                      <option value="1" <?php if($cnt['is_lost'] == 1){echo 'selected';} ?>>Yes</option>
                      <option value="0" <?php if($cnt['is_lost'] == 1){echo 'selected';} ?>>No</option>
                    </select>
                  </div>
                </div>

                
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Vehicle</label>
                    <select class="form-control" name="slcvehicle">
                      <option value="">Select Vehicle</option>
                      <?php
                      if(isset($vehicle))
                      {
                        foreach($vehicle as $cnt1)
                        {
                            if($cnt1['id']==$cnt['vehicle_id'])
                            {
                                print "<option value='".$cnt1['id']."' selected>".$cnt1['number']."</option>";
                            }else{
                                print "<option value='".$cnt1['id']."'>".$cnt1['number']."</option>";
                            }
                        }
                      } 
                      ?>
                    </select>
                  </div>
                </div>
                 
                
              </div>
                  <!-- /.box-body -->
                  <div class="box-footer">
                    <button type="submit" class="btn btn-success pull-right">Update</button>
                  </div>
                </form>
              <?php endforeach; ?>
            <?php endif; ?>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->