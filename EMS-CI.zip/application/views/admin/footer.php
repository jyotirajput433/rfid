 <footer class="main-footer">
    <div class="pull-right hidden-xs">
     
    </div>
    <strong>&copy; <?php echo date("Y"); ?></strong> <?php echo $profile[0]['name'];?>
  </footer>

</div>
<!-- ./wrapper -->


<!-- Bootstrap 3.3.7 -->
<script src="<?php echo base_url(); ?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- Slimscroll -->
<script src="<?php echo base_url(); ?>assets/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- bootstrap datepicker -->
<script src="<?php echo base_url(); ?>assets/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<!-- FastClick -->
<script src="<?php echo base_url(); ?>assets/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url(); ?>assets/dist/js/adminlte.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="<?php echo base_url(); ?>assets/dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url(); ?>assets/dist/js/demo.js"></script>
<!-- DataTables -->
<script src="<?php echo base_url(); ?>assets/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>

<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>

<!-- Date Picker -->
<script>
    $('#datepicker').datepicker({
      autoclose: true
    })
</script>

<!-- Datatable -->
<script>
  $(function () {
    $('#example1').DataTable()
    
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>


<script>
        // Function to fetch and update dashboard data
        function fetchData() {
            $.ajax({
                url: "<?php echo base_url('home/fetch_data'); ?>",
                type: "GET",
                dataType: "json",
                success: function(response) {
                    // Update the table with new data
                    updateTable(response);
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
        }

        // Function to update the table with new data
        function updateTable(data) {
        
            var tableBody = $('#dashboard tbody');
            tableBody.empty(); // Clear existing table rows
            
            // Populate table with new data
            $.each(data, function(index, entry) {
                var row = $('<tr>').appendTo(tableBody);
                $('<td>').text(index + 1).appendTo(row); // Sl No
                $('<td>').text(entry.rfid_value).appendTo(row);
                $('<td>').text(formatDate(entry.created_date)).appendTo(row);
                $('<td>').text(entry.gate_name).appendTo(row);
                $('<td>').text(entry.name).appendTo(row);
                $('<td>').text(entry.number).appendTo(row);
            });
        }

        // Function to format date (if needed)
        function formatDate(dateString) {
            var date = new Date(dateString);
            return date.getDate() + '-' + (date.getMonth() + 1) + '-' + date.getFullYear();
        }

        // Fetch data initially when the page loads
        $(document).ready(function() {
            fetchData();
            // Refresh data every 5 seconds
            setInterval(fetchData, 5000);
        });
    </script> 


<script>
        // Function to fetch and update dashboard data for a specific period
        $('#SearchForm').submit(function(event) {
        // Prevent the default form submission
        event.preventDefault();
        
        var searchKey = $('#quicksearchKeyWord').val().trim();
        var tableId =  'quickSearchTable'; 
        $.ajax({
                url: "<?php echo base_url('home/fetch_quickdata'); ?>",
                type: "GET",
                data: {    
                searchKey: searchKey
          }, // Send the selected period to the server
                dataType: "json",
                success: function(response) {

                  $('#dailyRecord').hide();
                  $('#quickSearchDiv').show();

                // Update the table with new data
                    updateAllTable(response, tableId);
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });


        });
                  
                  
        function fetchAllData(period, startDate, endDate, tableId) {
            $.ajax({
                url: "<?php echo base_url('home/fetch_Alldata'); ?>",
                type: "GET",
                data: {    
                  period: period,
            start_date: startDate,
            end_date: endDate
          }, // Send the selected period to the server
                dataType: "json",
                success: function(response) {
                  $('#dailyRecord').show();
                  $('#quickSearchDiv').hide();
                    // Update the table with new data
                    updateAllTable(response, tableId);
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
        }


//         $(document).ready(function() {
//     // Calculate start and end dates of the current month
//     var currentDate = new Date();
//     var startDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
//     var endDate = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);

//     // Format start and end dates as yyyy-mm-dd
 
//     // Fetch data for the current month
//     fetchAllData('month', formattedStartDate, formattedEndDate, 'monthTable');
// });


        // Function to update the table with new data
        function updateAllTable(data, tableId) {
            var table = $('#' + tableId);
            var tableBody = table.find('tbody');
            tableBody.empty(); // Clear existing table rows
            
            // Populate table with new data
            $.each(data, function(index, entry) {
                var row = $('<tr>').appendTo(tableBody);
                $('<td>').text(index + 1).appendTo(row); // Sl No
                $('<td>').text(entry.rfid_value).appendTo(row);
                $('<td>').text(formatDate(entry.created_date)).appendTo(row);
                $('<td>').text(entry.gate_name).appendTo(row);
                $('<td>').text(entry.name).appendTo(row);
                $('<td>').text(entry.number).appendTo(row);
            });
        }

        // Function to format date (if needed)
        function formatDate(dateString) {
            var date = new Date(dateString);
            return date.getDate() + '-' + (date.getMonth() + 1) + '-' + date.getFullYear();
        }

        // Fetch day data initially when the page loads
        $(document).ready(function() {
          var currentDate = new Date(); 
          var startDate = new Date(currentDate.setDate(currentDate.getDate()));
    var endDate = new Date(currentDate.setDate(currentDate.getDate()));
    var formattedStartDate = startDate.toISOString().slice(0,10);
        var formattedEndDate = endDate.toISOString().slice(0,10);

        $('#dailyRecord').show();
                  $('#quickSearchDiv').hide();
            fetchAllData('day', formattedStartDate, formattedEndDate, 'dayTable');
        });

        // Event handler for tab changes
// Event handler for tab changes
$('.nav-link').on('click', function() {
    var period = $(this).attr('href').substring(1); // Get the period from the href attribute
    var tableId = period + 'Table'; // Construct the table id based on the period
    var currentDate = new Date();

    // Fetch data based on the selected period
    if (period === 'day') {    
    var startDate = new Date(currentDate.setDate(currentDate.getDate()));
    var endDate = new Date(currentDate.setDate(currentDate.getDate()));
    } else if (period === 'week') {
    var weekStart = currentDate.getDate() - currentDate.getDay() + 1; // Calculate the date of the start of the week
    var weekEnd = weekStart + 6; // Calculate the date of the end of the week
    var startDate = new Date(currentDate.setDate(weekStart));
    var endDate = new Date(currentDate.setDate(weekEnd));
    } else if (period === 'month') {
        // Calculate start and end dates of the current month
        var startDate = new Date(currentDate.getFullYear(), currentDate.getMonth());
        var endDate = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
    }
        // Format start and end dates as yyyy-mm-dd
        var formattedStartDate = startDate.toISOString().slice(0,10);
        var formattedEndDate = endDate.toISOString().slice(0,10);

        // Fetch data for the current month
        fetchAllData(period, formattedStartDate, formattedEndDate, tableId);

});

$('#quickSearchForm').submit(function(event) {
    // Prevent default form submission
    event.preventDefault();
    
    // Get the search query entered by the user
    // var query = $('#vehicle_type').val().trim();
    var formData = $(this).serialize();
    // Make sure the search query is not empty
    $.ajax({
    url: "<?php echo base_url('home/advance_search'); ?>",
    type: "POST",
    data: formData,
    dataType: "json",
    success: function(response) {
        var selectedFromDate = $('input[name="fromDate"]').val();
        var selectedToDate = $('input[name="toDate"]').val();
        var selectedToTime = $('input[name="toTime"]').val();
        var selectedFromTime = $('input[name="fromTime"]').val();
        var gate_id = $('select[name="gate_id"]').val();
        var vehicleType = $('select[name="vehicle_type"]').val();
        var entryType = $('select[name="entry_type"]').val();
        var owner = $('select[name="transportor"]').val();
        var vehicle = $('select[name="vehicle_id"]').val();
      // Combine search results and form values into a single object
        var searchData = {
            searchResults: response,
            formValues: {
                fromDate: selectedFromDate,
                toDate: selectedToDate,
                toTime: selectedToTime,
                fromTime: selectedFromTime,
                gate_id: gate_id,
                vehicleType: vehicleType,
                entryType: entryType,
                owner: owner,
                vehicle: vehicle
                // Add other form values as needed
            }
        };
        // Encode the combined data as JSON string
        var searchDataJSON = JSON.stringify(searchData);
        // Encode the JSON string for URL
        var encodedSearchData = encodeURIComponent(searchDataJSON);
        // Redirect to another page with search results
        window.location.href = "<?php echo base_url('search_results'); ?>?data=" + encodedSearchData;
    },
        error: function(xhr, status, error) {
            console.error(error);
        }
    });
});

function updateSearchTable(data, tableId) {
            var table = $('#' + advSearch);
            var tableBody = table.find('tbody');
            tableBody.empty(); // Clear existing table rows
            
            // Populate table with new data
            $.each(data, function(index, entry) {
                var row = $('<tr>').appendTo(tableBody);
                $('<td>').text(index + 1).appendTo(row); // Sl No
                $('<td>').text(entry.rfid_value).appendTo(row);
                $('<td>').text(formatDate(entry.created_date)).appendTo(row);
                $('<td>').text(entry.gate_name).appendTo(row);
                $('<td>').text(entry.name).appendTo(row);
                $('<td>').text(entry.number).appendTo(row);
            });
        }

// ajax role
$('.form-check-input').on('click', function() {
    const menuId = $(this).data('menu');
    const roleId = $(this).data('role');

    $.ajax({
        url: "<?= base_url('role/changeaccess'); ?>",
        type: 'post',
        data: {
            menuId: menuId,
            roleId: roleId
        },
        success: function() {
            document.location.href = "<?= base_url('role/roleaccess/'); ?>" + roleId;
        }
    });
});


// ajax role
$('.form-check-input-view').on('click', function() {
    const menuId = $(this).data('menu');
    const roleId = $(this).data('role');

    const value = $(this).prop('checked') ? '1' : '0';

    $.ajax({
        url: "<?= base_url('role/changeaccessView'); ?>",
        type: 'post',
        data: {
            menuId: menuId,
            roleId: roleId, 
            value: value    
        },
        success: function() {
            document.location.href = "<?= base_url('role/roleaccess/'); ?>" + roleId;
        }
    });
});

// ajax role
$('.form-check-input-edit').on('click', function() {
    const menuId = $(this).data('menu');
    const roleId = $(this).data('role');
    const value = $(this).prop('checked') ? '1' : '0';

    $.ajax({
        url: "<?= base_url('role/changeaccessEdit'); ?>",
        type: 'post',
        data: {
            menuId: menuId,
            roleId: roleId,
            value: value    

        },
        success: function() {
            document.location.href = "<?= base_url('role/roleaccess/'); ?>" + roleId;
        }
    });
});

// ajax role
$('.form-check-input-delete').on('click', function() {
    const checkbox = $(this); // Reference to the clicked checkbox
   
    const menuId = $(this).data('menu');
    const roleId = $(this).data('role');
    const value =  checkbox.prop('checked') ? '1' : '0';

    $.ajax({
        url: "<?= base_url('role/changeaccessDelete'); ?>",
        type: 'post',
        data: {
            menuId: menuId,
            roleId: roleId,
            value: value    
        },
        success: function() {
            document.location.href = "<?= base_url('role/roleaccess/'); ?>" + roleId;
        }
    });
});
</script>


</body>
</html>
