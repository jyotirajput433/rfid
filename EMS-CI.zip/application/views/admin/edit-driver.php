  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Driver List
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Driver List</a></li>
        <li class="active">Edit Driver List</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">

        <?php if($this->session->flashdata('success')): ?>
          <div class="col-md-12">
            <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4><i class="icon fa fa-check"></i> Success!</h4>
                  <?php echo $this->session->flashdata('success'); ?>
            </div>
          </div>
        <?php elseif($this->session->flashdata('error')):?>
        <div class="col-md-12">
            <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4><i class="icon fa fa-check"></i> Failed!</h4>
                  <?php echo $this->session->flashdata('error'); ?>
            </div>
          </div>
        <?php endif;?>

        <!-- column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Edit Driver List</h3>
            </div>
            <!-- /.box-header -->

            <?php if(isset($content)): ?>
              <?php foreach($content as $cnt): ?>
                <!-- form start -->
                <form role="form" action="<?php echo base_url(); ?>update-driver" method="POST">
                <input type="hidden" name="txtid" value="<?php echo $cnt['id']; ?>" class="form-control">

                <div class="box-body">
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Name</label>
                    <input type="text" name="driver_name" class="form-control"  value="<?php echo $cnt['driver_name']; ?>">
                  </div>
                </div>

                <div class="col-md-6">
                <div class="form-group">
                    <label>Driver's Contact Number</label>
                    <input type="text" name="contact" class="form-control"  value="<?php echo $cnt['contact']; ?>">
                  </div>
                </div>

                <div class="col-md-6">
                <div class="form-group">
                    <label>Adhar Number</label>
                    <input type="text" name="adhar_id" class="form-control"  value="<?php echo $cnt['adhar_id']; ?>">
                  </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label>Owner</label>
                        <select class="form-control" name="transportor_id">
                        <option value="">Select</option>
                        <?php
                        if(isset($transportor))
                        {
                            foreach($transportor as $cnt1)
                            {
                                if($cnt1['id']==$cnt['transportor_id'])
                                {
                                  print "<option value='".$cnt1['id']."' selected>".$cnt1['name']."</option>";
                                }
                                else{
                                  print "<option value='".$cnt1['id']."'>".$cnt1['name']."</option>";
                                }
                            }
                        } 
                        ?>
                        </select>
                    </div>
                    </div>
                 
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Photo</label>
                    <input type="file" name="filephoto" class="form-control">
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="form-group">
                    <label>Active</label>
                    <select class="form-control" name="status">
                      <option value="">Select</option>
                      <option value="1" <?php if($cnt['status']==1) {echo 'selected';} ?>>Yes</option>
                      <option value="0" <?php if($cnt['status']==0) {echo 'selected';} ?>>No</option>
                    </select>
                  </div>
                </div>

                
                    
                 
                
              </div>
                  <!-- /.box-body -->
                  <div class="box-footer">
                    <button type="submit" class="btn btn-success pull-right">Update</button>
                  </div>
                </form>
              <?php endforeach; ?>
            <?php endif; ?>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->