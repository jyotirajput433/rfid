<?php
$encodedSearchData = isset($_GET['data']) ? $_GET['data'] : '';
// Decode the URL-encoded data
$searchDataJSON = urldecode($encodedSearchData);
// Decode the JSON data
$searchData = json_decode($searchDataJSON, true);
// Extract search results and form values
$searchResults = isset($searchData['searchResults']) ? $searchData['searchResults'] : [];
$formValues = isset($searchData['formValues']) ? $searchData['formValues'] : [];
?>


<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Result
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Result</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
     
   
      <div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-body">
					  <form id="quickSearchForm" >
                <!-- <div class="form-group col-sm-6 col-xs-6">
                  <input type="text" class="form-control" id="quickSearchInput" name="query" placeholder="Enter search query">
                </div> -->
                <div class="form-group col-sm-6 col-xs-6">
                  <input type="date" class="form-control" id="" value="<?php echo $formValues['fromDate']; ?>" name="fromDate">
                </div>
                <div class="form-group col-sm-6 col-xs-6">
                  <input type="date" class="form-control" id="" value="<?php echo $formValues['toDate']; ?>" name="toDate">
                </div>
                <div class="form-group col-sm-6 col-xs-6">
                  <input type="time" class="form-control" id="" value="<?php echo $formValues['fromTime']; ?>" name="fromTime">
                </div>
                <div class="form-group col-sm-6 col-xs-6">
                  <input type="time" class="form-control" id="" name="toTime" value="<?php echo $formValues['toTime']; ?>">
                </div>


                <div class="form-group col-sm-6 col-xs-6">
                  <select class="form-control" name="gate_id">
                    <option value="">Select Gate</option>
                    <?php
                    if(isset($gate))
                    {
                      foreach($gate as $cnt1)
                      {
                        if($cnt1['id']==$formValues['gate_id'])
                        {    
                          print "<option value='".$cnt1['id']."' selected>".$cnt1['gate_name']."</option>";
                        }
                        else{
                          print "<option value='".$cnt1['id']."'>".$cnt1['gate_name']."</option>";
                        }
                      }
                    } 
                    ?>
                  </select>
                </div>


                <div class="form-group col-sm-6 col-xs-6">
                  <select class="form-control" name="vehicle_type">
                    <option value="">Select vehicle type</option>
                    <?php
                    if(isset($vehicleType))
                    {
                      foreach($vehicleType as $cnt1)
                      {
                        if($cnt1['id']==$formValues['vehicleType'])
                        {    
                          print "<option value='".$cnt1['id']."' selected>".$cnt1['vehicle_name']."</option>";
                        }
                        else{
                          print "<option value='".$cnt1['id']."'>".$cnt1['vehicle_name']."</option>";
                        }
                      }
                    } 
                    ?>
                  </select>
                </div>
                
                <div class="form-group col-sm-6 col-xs-6">
                  <select class="form-control" name="entry_type">
                    <option value="">Select Entry Type</option>
                    <option value="1" <?php if($formValues['entryType'] == 1){echo 'selected'; }?>>In</option>";
                    <option value="2" <?php if($formValues['entryType'] == 2){echo 'selected';}?>>Out</option>";
                  </select>
                </div>

                <div class="form-group col-sm-6 col-xs-6">
                  <select class="form-control" name="vehicle_number">
                    <option value="">Select Registration Type</option>
                    <?php
                    if(isset($vehicle))
                    {
                      foreach($vehicle as $cnt1)
                      {
                        if($cnt1['id']==$cnt['number'])
                        {    
                          print "<option value='".$cnt1['id']."' selected>".$cnt1['number']."</option>";
                        }
                        else{
                          print "<option value='".$cnt1['id']."'>".$cnt1['number']."</option>";
                        }
                      }
                    } 
                    ?>
                  </select>
                </div>

                <div class="form-group col-sm-6 col-xs-6">
                  <select class="form-control" name="transportor" id="transportor">
                    <option value="">Select Owner</option>
                    <?php
                    if(isset($transportor))
                    {
                      foreach($transportor as $cnt1)
                      {
                        if($cnt1['id']==$formValues['owner'])
                        {    
                          print "<option value='".$cnt1['id']."' selected>".$cnt1['name']."</option>";
                        }
                        else{
                          print "<option value='".$cnt1['id']."'>".$cnt1['name']."</option>";
                        }
                      }
                    } 
                    ?>
                  </select>
                </div>

                <div class="form-group col-sm-6 col-xs-6">
                  <select class="form-control" name="vehicle_number">
                    <option value="">Select Vehicle </option>
                    <?php
                    if(isset($vehicle))
                    {
                      foreach($vehicle as $cnt1)
                      {
                        if($cnt1['id']==$cnt['number'])
                        {    
                          print "<option value='".$cnt1['id']."' selected>".$cnt1['number']."</option>";
                        }
                        else{
                          print "<option value='".$cnt1['id']."'>".$cnt1['number']."</option>";
                        }
                      }
                    } 
                    ?>
                  </select>
                </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Save changes</button>
          </div>
          </form>
        </div>
      </div>

      <div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-body">
						<div class="table-container">
            <div class="box-body">
              <div class="table-responsive">
                <table id="example1" id="advSearch" class="table table-bordered table-striped">
           
                            <thead>
                            <tr>
                                <th>Sl No</th>
                                <th>RFID</th>
                                <th>Date</th>
                                <th>Gate</th>
                                <th>Owner</th>
                                <th>Vehicle</th>
                            </tr>
                            </thead>
                            <tbody>
                       <?php     
                       if(isset($searchResults))
                        {
                        foreach($searchResults as $cnt1)
                        {
                            ?>
                            <tr>
                                <td><?php echo $cnt1['name'];?></td>
                                <td><?php echo $cnt1['rfid_value'];?></td>
                                <td><?php echo $cnt1['created_date'];?></td>
                                <td><?php echo $cnt1['gate_name'];?></td>
                                <td><?php echo $cnt1['name'];?></td>
                                <td><?php echo $cnt1['number'];?></td>
                            </tr>
                            <?php }}
                            ?>
							</tbody>
							  </table>
						  </div>
					  </div>	
				    </div>
				  </div>
			  </div>
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
