  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Transportor
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Transportor</a></li>
        <li class="active">Edit Transportor</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">

        <?php if($this->session->flashdata('success')): ?>
          <div class="col-md-12">
            <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4><i class="icon fa fa-check"></i> Success!</h4>
                  <?php echo $this->session->flashdata('success'); ?>
            </div>
          </div>
        <?php elseif($this->session->flashdata('error')):?>
        <div class="col-md-12">
            <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4><i class="icon fa fa-check"></i> Failed!</h4>
                  <?php echo $this->session->flashdata('error'); ?>
            </div>
          </div>
        <?php endif;?>

        <!-- column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Edit Transportor</h3>
            </div>
            <!-- /.box-header -->

            <?php if(isset($content)): ?>
              <?php foreach($content as $cnt): ?>
                <!-- form start -->
                <form role="form" action="<?php echo base_url(); ?>update-transportor" method="POST">
                  <div class="box-body">
                    <div class="col-md-6">
                  <div class="form-group">
                    <label>Name</label>
                    <input type="hidden" name="txtid" value="<?php echo $cnt['id'] ?>" class="form-control" placeholder="Full Name">

                    <input type="text" name="name" class="form-control"  value="<?php echo $cnt['name']; ?>" placeholder="Token No">
                  </div>
                </div>

                <div class="col-md-6">
                <div class="form-group">
                    <label>Contact</label>
                    <input type="text" name="contact"  value="<?php echo $cnt['contact']; ?>" class="form-control" placeholder="Full Name">
                  </div>
                </div>

                <div class="col-md-6">
                <div class="form-group">
                    <label>Email</label>
                    <input type="text" name="email"  value="<?php echo $cnt['email']; ?>"class="form-control" placeholder="Full Name">
                  </div>
                </div>

                <div class="col-md-6">
                <div class="form-group">
                    <label>Contract Valid Till</label>
                    <input type="text" name="contract_valid_till"  value="<?php echo $cnt['contract_valid_till']; ?>"class="form-control" placeholder="Full Name">
                  </div>
                </div>
                <div class="col-md-6">
                <div class="form-group">
                    <label>Adhar ID</label>
                    <input type="text" name="adhar_id"  value="<?php echo $cnt['adhar_id']; ?>" class="form-control" placeholder="Full Name">
                  </div>
                </div>

                <div class="col-md-6">
                <div class="form-group">
                    <label>No Of Vehicle</label>
                    <input type="text" name="no_of_vehicle"  value="<?php echo $cnt['no_of_vehicle']; ?>" class="form-control" placeholder="Full Name">
                  </div>
                </div>
                <div class="col-md-6">
                <div class="form-group">
                    <label>Contract No</label>
                    <input type="text" name="contract_no"  value="<?php echo $cnt['contract_no']; ?>" class="form-control" placeholder="contract_no">
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="form-group">
                    <label>Is it Valid transportor</label>
                    <select class="form-control" name="is_valid">
                      <option value="">Select</option>
                      <option value="1">Yes</option>
                      <option value="0">No</option>
                    </select>
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="form-group">
                    <label>Is Third Party</label>
                    <select class="form-control" name="is_third_party">
                      <option value="">Select</option>
                      <option value="1">Yes</option>
                      <option value="0">No</option>
                    </select>
                  </div>
                </div>


            </div>
                  <!-- /.box-body -->
                  <div class="box-footer">
                    <button type="submit" class="btn btn-success pull-right">Update</button>
                  </div>
                </form>
              <?php endforeach; ?>
            <?php endif; ?>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->