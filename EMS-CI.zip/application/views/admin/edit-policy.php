  <style>
  .floatybox {
     display: inline-block;
     width: 123px;
}
  </style>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Policy Management
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Policy Management</a></li>
        <li class="active">Edit Policy</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">

        <?php echo validation_errors('<div class="col-md-12">
            <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4><i class="icon fa fa-check"></i> Failed!</h4>', '</div>
          </div>'); ?>

        <?php if($this->session->flashdata('success')): ?>
          <div class="col-md-12">
            <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4><i class="icon fa fa-check"></i> Success!</h4>
                  <?php echo $this->session->flashdata('success'); ?>
            </div>
          </div>
        <?php elseif($this->session->flashdata('error')):?>
        <div class="col-md-12">
            <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4><i class="icon fa fa-check"></i> Failed!</h4>
                  <?php echo $this->session->flashdata('error'); ?>
            </div>
          </div>
        <?php endif;?>

        <!-- column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Edit Policy</h3>
            </div>
            <!-- /.box-header -->

            <?php if(isset($content)): ?>
              <?php foreach($content as $cnt): ?>
                  <!-- form start -->
                  <?php echo form_open_multipart('Policy/update');?>
                  <div class="box-body">
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Policy</label>
                    <input type="hidden" name="txtid" value="<?php echo $cnt['id']; ?>" class="form-control">
                    <input type="text" name="policy_name" class="form-control" value="<?php echo $cnt['policy_name']; ?>" >
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Allowed Days</label>
                    <input type="number" name="allowed_days" class="form-control" value="<?php echo $cnt['allowed_days']; ?>" >
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="form-group">
                    <label>Access Type</label>
                    <select class="form-control" name="access_type">
                      <option value="">Select</option>
                      <option value="1" <?php if($cnt['access_type'] == 1) {echo 'selected'; } ?>>All</option>
                      <option value="0" <?php if($cnt['access_type'] == 0) {echo 'selected'; } ?>>No</option>
                    </select>
                  </div>
                </div>  

                <div class="col-md-6">
                  <div class="form-group">
                    <label>All Days</label>
                    <select class="form-control" name="all_days">
                      <option value="">Select</option>
                      <option value="1" <?php if($cnt['all_days'] == 1) {echo 'selected'; } ?>>Yes</option>
                      <option value="0" <?php if($cnt['all_days'] == 0) {echo 'selected'; } ?>>No</option>
                    </select>
                  </div>
                </div>  

               

                <div class="col-md-6">
                  <div class="form-group">
                    <label>From Time</label>
                    <input type="date" name="from_time" class="form-control" value="<?php echo date('Y-m-d',strtotime($cnt["from_time"])); ?>">
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="form-group">
                    <label>To Time</label>
                    <input type="date" name="to_time" class="form-control" value="<?php echo date('Y-m-d',strtotime($cnt["to_time"]));?>">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Special Days</label>
                    <select class="form-control" name="special_days">
                      <option value="">Select</option>
                      <option value="1" <?php if($cnt['special_days'] == 1) {echo 'selected'; } ?>>Yes</option>
                      <option value="0" <?php if($cnt['special_days'] == 1) {echo 'selected'; } ?>>No</option>
                    </select>
                  </div>
                </div>  
                
              </div>
                    <!-- /.box-body -->
                    <div class="box-footer">
                      <button type="submit" class="btn btn-success pull-right">Submit</button>
                    </div>
                  </form>
                <?php endforeach; ?>
            <?php endif; ?>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->