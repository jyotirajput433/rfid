<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }

    protected function load_common_data() {
        
      //  $data['allpermission'] = $this->Staff_model->select_staff_byID($this->session->userdata('userid'));
      //  $permissions = explode(",", $data['allpermission'][0]['permission']);
       // $data['permissions'] = $permissions;
        $data =  $this->get_common_data();
        $this->load->view('admin/header',$data);
        }
    protected function get_common_data() {
        $this->load->model('Home_model');
        $this->load->model('Staff_model');
        $this->load->model('Role_model');

        $data['profile'] = $this->Home_model->select_profile();
        $data['getpermission'] = $this->Role_model->select_roleaccess_byID($this->session->userdata('usertype'));
        
      //  $data['allpermission'] = $this->Staff_model->select_staff_byID($this->session->userdata('userid'));
      //  $permissions = explode(",", $data['allpermission'][0]['permission']);
       // $data['permissions'] = $permissions;
        
        return $data;
        }

        protected function check_permission($permission_id) {
            // Call the load_common_data() method to get the common data
            $common_data = $this->get_common_data();
    
            // Access the getpermission data
            $getpermission = $common_data['getpermission'];
    
            // Filter the permissions array to find if the permission for view or edit is available
            $filtered_permissions = array_filter($getpermission, function($permission) use ($permission_id) {
                return $permission['permission_id'] == $permission_id;
            });
    
            // If any permissions match the criteria, the user has permission
            return !empty($filtered_permissions);
        }

        protected function check_permission_add($permission_id) {
            // Call the load_common_data() method to get the common data
            $common_data = $this->get_common_data();
    
            // Access the getpermission data
            $getpermission = $common_data['getpermission'];
            $has_permission = false;

            // Loop through the permissions to check for the desired permission
            foreach ($getpermission as $permission) {
                if ($permission['permission_id'] == $permission_id && $permission['view'] == '1') {
                    // If the permission for view is available, set the flag to true and break the loop
                    $has_permission = true;
                    break;
                }
            }
    
            // Return the result of permission check
            return $has_permission;
        }


        protected function check_permissions($permissions) {
            // Call the load_common_data() method to get the common data
            $common_data = $this->get_common_data();
            $has_permission = false;

            // Access the getpermission data
            $getpermission = $common_data['getpermission'];
            foreach ($permissions as $permission) {
            $permission_id = $permission['permission_id'];
            $permission_type = $permission['type'];

            // Check if the permission type is valid
            if (!in_array($permission_type, ['view', 'edit', 'delete','manage'])) {
                continue; // Skip invalid permission type
            }

            foreach ($getpermission as $perm) {

                if($permission_type == 'manage')
                {
                    $condition = '';
                }else
                {
                    $condition = '&&'.$perm[$permission_type].'== 1';

                }

             
                 if ($perm['permission_id'] == $permission_id . $condition) {
                     // If the permission is available for the specified type, set the flag to true and break the loop
                    $has_permission = true;
                    break 2; // Break both loops
                }
            }
        }

        // Return the result of permission check
        return $has_permission;
    }

        protected function check_permission_edit($permission_id) {
            // Call the load_common_data() method to get the common data
            $common_data = $this->get_common_data();
    
            // Access the getpermission data
            $getpermission = $common_data['getpermission'];
    
            // Filter the permissions array to find if the permission for view or edit is available
            $filtered_permissions = array_filter($getpermission, function($permission) use ($permission_id) {
                return $permission['permission_id'] == $permission_id && $permission['edit'] == '1';
            });
    
            // If any permissions match the criteria, the user has permission
            return !empty($filtered_permissions);
        }

        protected function check_permission_delete($permission_id) {
            // Call the load_common_data() method to get the common data
            $common_data = $this->get_common_data();
    
            // Access the getpermission data
            $getpermission = $common_data['getpermission'];
    
            // Filter the permissions array to find if the permission for view or edit is available
            $filtered_permissions = array_filter($getpermission, function($permission) use ($permission_id) {
                return $permission['permission_id'] == $permission_id && $permission['delete'] == '1';
            });
    
            // If any permissions match the criteria, the user has permission
            return !empty($filtered_permissions);
        }
}