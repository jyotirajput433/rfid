<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Driver extends MY_Controller {

    function __construct()
    {
        parent::__construct();
        if ( ! $this->session->userdata('logged_in'))
        { 
            redirect(base_url().'login');
        }
    }

    public function index()
    {
         $data['transportor']=$this->Transportor_model->select_transportor();
      //  $data['country']=$this->Home_model->select_countries();
        $this->load_common_data();
        $this->load->view('admin/add-driver',$data);
        $this->load->view('admin/footer');
    }

    public function manage()
    {
         $data['content']=$this->Driver_model->select_driver();
        $this->load_common_data();
        $this->load->view('admin/manage-driver',$data);
        $this->load->view('admin/footer');
    }

    public function insert()
    {
        $this->form_validation->set_rules('driver_name', 'Name', 'required');
        $this->form_validation->set_rules('contact', 'Contact', 'required');
        $this->form_validation->set_rules('adhar_id', 'Adhar', 'required');
        $this->form_validation->set_rules('transportor_id', 'Owner', 'required');
        $this->form_validation->set_rules('status', 'Status', 'required');
        
        
        $number=$this->input->post('contact');
        $name=$this->input->post('driver_name');
        $adhar=$this->input->post('adhar_id');
        $t_id=$this->input->post('transportor_id');
        $status=$this->input->post('status');
       
        
        $added=$this->session->userdata('userid');
        $createdTime = date("y-m-d");

        if($this->form_validation->run() !== false)
        {

            $this->load->library('image_lib');
            $config['upload_path']= 'uploads/profile-pic/';
            $config['allowed_types'] ='gif|jpg|png|jpeg';
            $this->load->library('upload', $config);
            if ( ! $this->upload->do_upload('filephoto'))
            {
                $image='default-pic.jpg';
            }
            else
            {
                $image_data =   $this->upload->data();

                $configer =  array(
                  'image_library'   => 'gd2',
                  'source_image'    =>  $image_data['full_path'],
                  'maintain_ratio'  =>  TRUE,
                  'width'           =>  150,
                  'height'          =>  150,
                  'quality'         =>  50
                );
                $this->image_lib->clear();
                $this->image_lib->initialize($configer);
                $this->image_lib->resize();
                
                $image=$image_data['file_name'];
            }


            $insert_driverData = array(
                'driver_name'=>$name,
                'contact'=>$number,
                'photo'=>$image,
                'status'=>$status,
                'transportor_id'=>$t_id,
                'adhar_id'=>$adhar,
                'created_by'=>$added,
                'created_date'=>$createdTime,
               );
            $data=$this->Driver_model->insert_driver($insert_driverData);
          
            if($data==true)
            {
                
                $this->session->set_flashdata('success', "New Staff Added Succesfully"); 
            }else{
                $this->session->set_flashdata('error', "Sorry, New Staff Adding Failed.");
            }
            redirect($_SERVER['HTTP_REFERER']);
        }
        else{
            $this->index();
            return false;

        } 
    }

    public function update()
    {
        $this->load->helper('form');
        $this->form_validation->set_rules('driver_name', 'Name', 'required');
        $this->form_validation->set_rules('contact', 'Contact', 'required');
        $this->form_validation->set_rules('adhar_id', 'Adhar', 'required');
        $this->form_validation->set_rules('transportor_id', 'Owner', 'required');
        $this->form_validation->set_rules('status', 'Status', 'required');
        
        
        $number=$this->input->post('contact');
        $name=$this->input->post('driver_name');
        $adhar=$this->input->post('adhar_id');
        $t_id=$this->input->post('transportor_id');
        $status=$this->input->post('status');
        
        $id=$this->input->post('txtid');
        
        $added=$this->session->userdata('userid');
        $createdTime = date("y-m-d");

        if($this->form_validation->run() !== false)
        {
            $this->load->library('image_lib');
            $config['upload_path']= 'uploads/profile-pic/';
            $config['allowed_types'] ='gif|jpg|png|jpeg';
            $this->load->library('upload', $config);
            if ( ! $this->upload->do_upload('filephoto'))
            {
                $update_driverData = array(
                    'driver_name'=>$name,
                    'contact'=>$number,
                    'status'=>$status,
                    'transportor_id'=>$t_id,
                    'adhar_id'=>$adhar,
                    'updated_by'=>$added,
                    'updated_date'=>$createdTime,
                   );
    
                $data=$this->Driver_model->update_driver($update_driverData,$id);   }
            else
            {
                $image_data =   $this->upload->data();

                $configer =  array(
                  'image_library'   => 'gd2',
                  'source_image'    =>  $image_data['full_path'],
                  'maintain_ratio'  =>  TRUE,
                  'width'           =>  150,
                  'height'          =>  150,
                  'quality'         =>  50
                );
                $this->image_lib->clear();
                $this->image_lib->initialize($configer);
                $this->image_lib->resize();
                $image=$image_data['file_name'];

                $update_driverData = array(
                    'driver_name'=>$name,
                    'contact'=>$number,
                    'photo'=>$image,
                    'status'=>$status,
                    'transportor_id'=>$t_id,
                    'adhar_id'=>$adhar,
                    'updated_by'=>$added,
                    'updated_date'=>$createdTime,
                   );
    
                $data=$this->Driver_model->update_driver($update_driverData,$id);
            }
            
            if($this->db->affected_rows() > 0)
            {
                $this->session->set_flashdata('success', "Staff Updated Succesfully"); 
            }else{
                $this->session->set_flashdata('error', "Sorry, Staff Updated Failed.");
            }
            redirect(base_url()."manage-driver");
        }
        else{
            redirect($_SERVER['HTTP_REFERER']);
            return false;
      

        } 
    }


    function edit($id)
    {
        $data['transportor']=$this->Transportor_model->select_transportor();

        $data['content']=$this->Driver_model->select_driver_byID($id);
        $this->load_common_data();
        $this->load->view('admin/edit-driver',$data);
        $this->load->view('admin/footer');
    }


    function delete($id)
    {
        $this->Home_model->delete_login_byID($id);
        $data=$this->Staff_model->delete_staff($id);
        if($this->db->affected_rows() > 0)
        {
            $this->session->set_flashdata('success', "Staff Deleted Succesfully"); 
        }else{
            $this->session->set_flashdata('error', "Sorry, Staff Delete Failed.");
        }
        redirect($_SERVER['HTTP_REFERER']);
    }

    



}
