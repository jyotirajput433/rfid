<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Devicelist extends MY_Controller {

    function __construct()
    {
        parent::__construct();
        if ( ! $this->session->userdata('logged_in'))
        { 
            redirect(base_url().'login');
        }
    }

    public function index()
    {
         $data['deviceType']=$this->Device_model->select_device();
         $data['gate']=$this->Gate_model->select_gate();
      //  $data['country']=$this->Home_model->select_countries();
        $this->load_common_data();

        $this->load->view('admin/add-devicelist',$data);
        $this->load->view('admin/footer');
    }

    public function manage()
    {
        $data['content']=$this->Devicelist_model->select_devicelist();
        $this->load_common_data();

        $this->load->view('admin/manage-devicelist',$data);
        $this->load->view('admin/footer');
    }

    public function insert()
    {
        $this->form_validation->set_rules('ip_address', 'name', 'required');
        $this->form_validation->set_rules('slcdevice', 'Device', 'required');
        $this->form_validation->set_rules('slcgate', 'Gate', 'required');
        $this->form_validation->set_rules('direction', 'Direction', 'required');
        $this->form_validation->set_rules('mac_address', 'MAC Address', 'required');
        $this->form_validation->set_rules('make', 'Make', 'required');
        $this->form_validation->set_rules('model', 'Model', 'required');
        $this->form_validation->set_rules('url', 'URL', 'required');
        
        $ip_address=$this->input->post('ip_address');
        $deviceType=$this->input->post('slcdevice');
        $gate=$this->input->post('slcgate');
        $direction=$this->input->post('direction');
        $mac_address=$this->input->post('mac_address');
        $make=$this->input->post('make');
        $model=$this->input->post('model');
        $url=$this->input->post('url');
        $added=$this->session->userdata('userid');

        if($this->form_validation->run() !== false)
        {

            $insert_devicelistData = array(
                'ip_address'=>$ip_address   ,
                'devicetype_id'=>$deviceType,
                'gate_id'   =>$gate,
                'direction'=>$direction,
                'mac_address'=>$mac_address,
                'make'=>$make,
                'model'=>$model,
                'url'=>$url,
                'status'=>1,
                'created_by'=>$added,
                'created_date'=>date("Y-m-d")
               );
            $data=$this->Devicelist_model->insert_devicelist($insert_devicelistData);
          
            if($data==true)
            {
                
                $this->session->set_flashdata('success', "New Device Added Succesfully"); 
            }else{
                $this->session->set_flashdata('error', "Sorry, New Staff Adding Failed.");
            }
            redirect($_SERVER['HTTP_REFERER']);
        }
        else{
            $this->index();
            return false;

        } 
    }

    public function update()
    {
        $this->load->helper('form');
        $this->form_validation->set_rules('ip_address', 'name', 'required');
        $this->form_validation->set_rules('slcdevice', 'Device', 'required');
        $this->form_validation->set_rules('slcgate', 'Gate', 'required');
        $this->form_validation->set_rules('direction', 'Direction', 'required');
        $this->form_validation->set_rules('mac_address', 'MAC Address', 'required');
        $this->form_validation->set_rules('make', 'Make', 'required');
        $this->form_validation->set_rules('model', 'Model', 'required');
        $this->form_validation->set_rules('url', 'URL', 'required');

        $id=$this->input->post('txtid');

        $ip_address=$this->input->post('ip_address');
        $deviceType=$this->input->post('slcdevice');
        $gate=$this->input->post('slcgate');
        $direction=$this->input->post('direction');
        $mac_address=$this->input->post('mac_address');
        $make=$this->input->post('make');
        $model=$this->input->post('model');
        $url=$this->input->post('url');
        $added=$this->session->userdata('userid');


        $update_devicelistData = array(
            'ip_address'=>$ip_address,
            'devicetype_id'=>$deviceType,
            'gate_id'   =>$gate,
            'direction'=>$direction,
            'mac_address'=>$mac_address,
            'make'=>$make,
            'model'=>$model,
            'url'=>$url,
            'status'=>1,
            'updated_by'=>$added,
            'updated_date'=>date("Y-m-d")
           );

        if($this->form_validation->run() !== false)
        {
           $data=$this->Devicelist_model->update_devicelist($update_devicelistData,$id);
         
            if($this->db->affected_rows() > 0)
            {
                $this->session->set_flashdata('success', "Device List Updated Succesfully"); 
            }else{
                $this->session->set_flashdata('error', "Sorry, Device List Updated Failed.");
            }
            redirect(base_url()."manage-devicelist");
        }
        else{
            redirect($_SERVER['HTTP_REFERER']);
        return false;
  

        } 
    }


    function edit($id)
    {
        $data['deviceType']=$this->Device_model->select_device();
        
        $data['department']=$this->Department_model->select_departments();
        $data['country']=$this->Home_model->select_countries();
        $data['content']=$this->Devicelist_model->select_devicelist_byID($id);
        $data['gate']=$this->Gate_model->select_gate();
        
        $this->load_common_data();

        $this->load->view('admin/edit-devicelist',$data);
        $this->load->view('admin/footer');
    }


    function delete($id)
    {
        $this->Home_model->delete_login_byID($id);
        $data=$this->Staff_model->delete_staff($id);
        if($this->db->affected_rows() > 0)
        {
            $this->session->set_flashdata('success', "Staff Deleted Succesfully"); 
        }else{
            $this->session->set_flashdata('error', "Sorry, Staff Delete Failed.");
        }
        redirect($_SERVER['HTTP_REFERER']);
    }

    



}
