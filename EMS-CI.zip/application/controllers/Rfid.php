<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rfid extends MY_Controller {

    function __construct()
    {
        parent::__construct();
        if ( ! $this->session->userdata('logged_in'))
        { 
            redirect(base_url().'login');
        }
    }

    public function index()
    {
         $data['vehicle']=$this->Vehicle_model->select_vehicle();
      //  $data['country']=$this->Home_model->select_countries();
        $this->load_common_data();
        $data['get_last_token']=$this->Rfid_model->get_token();

        
        $this->load->view('admin/add-rfid',$data);
        $this->load->view('admin/footer');
    }

    public function manage()
    {
        $data['content']=$this->Rfid_model->select_rfid();
        $this->load_common_data();
        $this->load->view('admin/manage-rfid',$data);
        $this->load->view('admin/footer');
    }

    public function insert()
    {
        $this->form_validation->set_rules('token_no', 'Token No', 'required');
        $this->form_validation->set_rules('rfid_value', 'RFID Value', 'required');
        $this->form_validation->set_rules('is_valid', 'Is Valid', 'required');
        $this->form_validation->set_rules('is_allocated', 'Is allocated', 'required');
        $this->form_validation->set_rules('is_lost', 'Is Lost', 'required');
        $this->form_validation->set_rules('slcvehicle', 'Vehicle Detail', 'required');

                
        $token=$this->input->post('token_no');
        $rfidValue=$this->input->post('rfid_value');
        $isValid=$this->input->post('is_valid');
        $isAllocated=$this->input->post('is_allocated');
        $isLost=$this->input->post('is_lost');
        $vehicle=$this->input->post('slcvehicle');
        $added=$this->session->userdata('userid');

        if($this->form_validation->run() !== false)
        {

            $insert_rfidData = array(
                'token_no'=>$token,
                'rfid_value'=>$rfidValue,
                'is_valid'=>$isValid,
                'is_allocated'=>$isAllocated,
                'is_lost'=>$isLost,
                'vehicle_id'=>$vehicle,
                'created_by'=>$added
               );
            $data=$this->Rfid_model->insert_rfid($insert_rfidData);
          
            if($data==true)
            {
                
                $this->session->set_flashdata('success', "New Staff Added Succesfully"); 
            }else{
                $this->session->set_flashdata('error', "Sorry, New Staff Adding Failed.");
            }
            redirect($_SERVER['HTTP_REFERER']);
        }
        else{
            $this->index();
            return false;

        } 
    }

    public function update()
    {
        $this->load->helper('form');

        $this->form_validation->set_rules('token_no', 'Token No', 'required');
        $this->form_validation->set_rules('rfid_value', 'RFID Value', 'required');
        $this->form_validation->set_rules('is_valid', 'Is Valid', 'required');
        $this->form_validation->set_rules('is_allocated', 'Is allocated', 'required');
        $this->form_validation->set_rules('is_lost', 'Is Lost', 'required');
        $this->form_validation->set_rules('slcvehicle', 'Vehicle Detail', 'required');


       // $token=$this->input->post('token_no');
        $rfidValue=$this->input->post('rfid_value');
        $isValid=$this->input->post('is_valid');
        $isAllocated=$this->input->post('is_allocated');
        $isLost=$this->input->post('is_lost');
        $vehicle=$this->input->post('slcvehicle');
        $added=$this->session->userdata('userid');

        if($this->form_validation->run() !== false)
        {
            $update_rfidData = array(
                'token_no'=>$token,
                'rfid_value'=>$rfidValue,
                'is_valid'=>$isValid,
                'is_allocated'=>$isAllocated,
                'is_lost'=>$isLost,
                'vehicle_id'=>$vehicle,
                'updated_by'=>$added
               );
            }
            if($this->form_validation->run() !== false)
            {
                $data=$this->Rfid_model->update_rfid($update_rfidData,$id);
                if($this->db->affected_rows() > 0)
                {
                    $this->session->set_flashdata('success', "RFID Updated Succesfully"); 
                }else{
                    $this->session->set_flashdata('error', "Sorry, RFID Update Failed.");
                }
                redirect(base_url()."manage-rfid");
            }else{
                redirect($_SERVER['HTTP_REFERER']);
                return false;
            }
    }


    function edit($id)
    {
        $data['vehicle']=$this->Vehicle_model->select_vehicle();
        $data['department']=$this->Department_model->select_departments();
        $data['country']=$this->Home_model->select_countries();
        $data['content']=$this->Rfid_model->select_rfid_byID($id);
        $this->load_common_data();
        $this->load->view('admin/edit-rfid',$data);
        $this->load->view('admin/footer');
    }


    function delete($id)
    {
        $this->Home_model->delete_login_byID($id);
        $data=$this->Rfid_model->delete_rfid($id);
        if($this->db->affected_rows() > 0)
        {
            $this->session->set_flashdata('success', "Rfid Deleted Succesfully"); 
        }else{
            $this->session->set_flashdata('error', "Sorry, Rfid Delete Failed.");
        }
        redirect($_SERVER['HTTP_REFERER']);
    }

    public function upload_csv() {
        $tokenStartFrom=$this->input->post('token_start');
        $config['upload_path']   = './uploads/';
        $config['allowed_types'] = 'csv';
        $config['max_size']      = 1024; // 1MB
        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('csv_file')) {
            // File upload failed
            $error = $this->upload->display_errors();
            // Handle the error (display error message or redirect back to the form with error message)
        } else {
            // File uploaded successfully
            $file_data = $this->upload->data();
            $file_path = $file_data['full_path'];
            $this->import_csv_to_database($file_path,$tokenStartFrom);
        }
    }

    private function import_csv_to_database($file_path,$tokenStartFrom) {
        // Load the CSV reader library
        $this->load->library('csvreader');
        $csv_data = $this->csvreader->parse_file($file_path);

        // Skip the first row (header) and start from row 2
        $csv_data = array_slice($csv_data, 1);
        

        $tokenNo = $tokenStartFrom;
        // Insert data into the database
        foreach ($csv_data as $row) {
            do {
                $checkToken = $this->Rfid_model->is_token_exist($tokenStartFrom);
                if (!empty($checkToken)) {
                    $tokenStartFrom++;
                }
            } while (!empty($checkToken));
            
            $tokenNo = $tokenStartFrom;
            
            $data = array(
                'token_no' => $tokenNo,
                'rfid_value' => $row[0],
                // Add other fields as needed
                'created_date' => date('Y-m-d H:i:s'),
                'updated_date' => $this->session->userdata('userid')

            );
            $this->Rfid_model->insert_rfid($data);
            $tokenStartFrom = $tokenNo; 
        }
        $this->session->set_flashdata('success', "Data Inserted Succesfully"); 
        redirect(base_url()."manage-rfid");
        
    }

    



}
