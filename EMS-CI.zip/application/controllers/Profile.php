<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends MY_Controller {

    function __construct()
    {
        parent::__construct();
        if ( ! $this->session->userdata('logged_in'))
        { 
            redirect(base_url().'login');
        }
    }

    public function index()
    {
        $data['content']=$this->Home_model->select_profile();
        $this->load_common_data();
        $this->load->view('admin/view-profile',$data);
        $this->load->view('admin/footer');
    }


    public function update()
    {
        $id=$this->input->post('txtid');
        $name=$this->input->post('name');
        $aname=$this->input->post('admin_name');
        $data=$this->Home_model->update_profile(array('name'=>$name,'admin_name'=>$aname),$id);
        if($this->db->affected_rows() > 0)
        {
            $this->session->set_flashdata('success', "Profile Updated Succesfully"); 
        }else{
            $this->session->set_flashdata('error', "Sorry, Profile Update Failed.");
        }
        redirect(base_url()."manage-profile");
    }   


    function edit($id)
    {
        $data['content']=$this->Home_model->select_profile($id);
        $this->load_common_data();
        $this->load->view('admin/view-profile',$data);
        $this->load->view('admin/footer');
    }
}
