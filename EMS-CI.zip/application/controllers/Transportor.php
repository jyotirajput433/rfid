<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Transportor extends MY_Controller {

    function __construct()
    {
        parent::__construct();
        if ( ! $this->session->userdata('logged_in'))
        { 
            redirect(base_url().'login');
        }
    }

    public function index()
    {
         $data['vehicle']=$this->Vehicle_model->select_vehicle();
      //  $data['country']=$this->Home_model->select_countries();
        $this->load_common_data();
        $this->load->view('admin/add-transportor',$data);
        $this->load->view('admin/footer');
    }

    public function manage()
    {
        $data['content']=$this->Transportor_model->select_transportor();
        $this->load_common_data();
        $this->load->view('admin/manage-transportor',$data);
        $this->load->view('admin/footer');
    }

    public function insert()
    {
        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('contact', 'Contact Number', 'required');
        $this->form_validation->set_rules('is_valid', 'Valid', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('contract_valid_till', 'Validity', 'required');
        $this->form_validation->set_rules('contract_no', 'Contract Number', 'required');
        $this->form_validation->set_rules('adhar_id', 'Adhar Id', 'required');
        $this->form_validation->set_rules('no_of_vehicle', 'NO of Vehicle', 'required');
        $this->form_validation->set_rules('is_third_party', 'Third Party Owner', 'required');


        $name=$this->input->post('name');
        $contact=$this->input->post('contact');
        $isValid=$this->input->post('is_valid');
        $email=$this->input->post('email');
        $contract_valid_till=$this->input->post('contract_valid_till');
        $contract_no=$this->input->post('contract_no');
        $adhar_id=$this->input->post('adhar_id');
        $no_of_vehicle=$this->input->post('no_of_vehicle');
        $is_third_party=$this->input->post('is_third_party');
        $added=$this->session->userdata('userid');

        if($this->form_validation->run() !== false)
        {

            $insert_transportorData = array(
                'name'=>$name,
                'contact'=>$contact,
                'is_valid'=>$isValid,
                'email'=>$email,
                'contract_valid_till'=>$contract_valid_till,
                'contract_no'=>$contract_no,
                'adhar_id'=>$adhar_id,
                'no_of_vehicle'=>$no_of_vehicle,
                'created_by'=>$added,
                'is_third_party'=>$is_third_party,
                'created_date'=>date("Y-m-d")
               );
            $data=$this->Transportor_model->insert_transportor($insert_transportorData);
          
            if($data==true)
            {
                
                $this->session->set_flashdata('success', "New Staff Added Succesfully"); 
            }else{
                $this->session->set_flashdata('error', "Sorry, New Staff Adding Failed.");
            }
            redirect($_SERVER['HTTP_REFERER']);
        }
        else{
            $this->index();
            return false;

        } 
    }

    public function update()
    {
        $this->load->helper('form');
        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('contact', 'Contact Number', 'required');
        $this->form_validation->set_rules('is_valid', 'Valid', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('contract_valid_till', 'Validity', 'required');
        $this->form_validation->set_rules('contract_no', 'Contract Number', 'required');
        $this->form_validation->set_rules('adhar_id', 'Adhar Id', 'required');
        $this->form_validation->set_rules('no_of_vehicle', 'NO of Vehicle', 'required');
        $this->form_validation->set_rules('is_third_party', 'Third Party Owner', 'required');

        $id=$this->input->post('txtid');
        $name=$this->input->post('name');
        $contact=$this->input->post('contact');
        $isValid=$this->input->post('is_valid');
        $email=$this->input->post('email');
        $contract_valid_till=$this->input->post('contract_valid_till');
        $contract_no=$this->input->post('contract_no');
        $adhar_id=$this->input->post('adhar_id');
        $no_of_vehicle=$this->input->post('no_of_vehicle');
        $is_third_party=$this->input->post('is_third_party');
        $added=$this->session->userdata('userid');


        $update_transportorData = array(
            'name'=>$name,
            'contact'=>$contact,
            'is_valid'=>$isValid,
            'email'=>$email,
            'contract_valid_till'=>$contract_valid_till,
            'contract_no'=>$contract_no,
            'adhar_id'=>$adhar_id,
            'no_of_vehicle'=>$no_of_vehicle,
            'updated_by'=>$added,
            'is_third_party'=>$is_third_party,
            'updated_date'=>date("Y-m-d")
           );
        if($this->form_validation->run() !== false)
        {
           $data=$this->Transportor_model->update_transportor($update_transportorData,$id);
         
            if($this->db->affected_rows() > 0)
            {
                $this->session->set_flashdata('success', "Staff Updated Succesfully"); 
            }else{
                $this->session->set_flashdata('error', "Sorry, Staff Updated Failed.");
            }
            redirect(base_url()."manage-transportor");
        }
        else{
            redirect($_SERVER['HTTP_REFERER']);
                return false;

        } 
    }


    function edit($id)
    {
        $data['department']=$this->Department_model->select_departments();
        $data['country']=$this->Home_model->select_countries();
        $data['content']=$this->Transportor_model->select_transportor_byID($id);
        $this->load_common_data();
        $this->load->view('admin/edit-transportor',$data);
        $this->load->view('admin/footer');
    }


    function delete($id)
    {
        $this->Home_model->delete_login_byID($id);
        $data=$this->Staff_model->delete_staff($id);
        if($this->db->affected_rows() > 0)
        {
            $this->session->set_flashdata('success', "Staff Deleted Succesfully"); 
        }else{
            $this->session->set_flashdata('error', "Sorry, Staff Delete Failed.");
        }
        redirect($_SERVER['HTTP_REFERER']);
    }

    



}
