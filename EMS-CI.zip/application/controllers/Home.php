<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends MY_Controller {

    function __construct()
    {
        parent::__construct();
    }

	public function index()
	{
        if ( ! $this->session->userdata('logged_in'))
        { 
            redirect(base_url('login'));
        }
		else
        {
           
            // if($this->session->userdata('usertype')==1)
            // {
                $this->load_common_data();
                $data['vehcle']=$this->Vehicle_model->select_vehicle();
                $data['vehicleType']=$this->Home_model->select_vehicleType();
                $data['rfid']=$this->Rfid_model->select_rfid();
                $data['policy']=$this->Policy_model->select_policy();
                $data['transportor']=$this->Transportor_model->select_transportor();
                $data['driver']=$this->Driver_model->select_driver();

             //   $this->load->view('admin/header',$data);
                $this->load->view('admin/dashboard');
                $this->load->view('admin/footer');
            // }
            // else{
            //     $staff=$this->session->userdata('userid');
            //     $data['leave']=$this->Leave_model->select_leave_byStaffID($staff);
            //     $this->load->view('staff/header');
            //     $this->load->view('staff/dashboard',$data);
            //     $this->load->view('staff/footer');
            // }
            
        }
	}

    public function login_page()
    {
        $this->load->view('login');
    }

    public function error_page()
    {
        $this->load->view('admin/header');
        $this->load->view('admin/error_page');
        $this->load->view('admin/footer');
    }

	function login()
    {
        $un=$this->input->post('txtusername');
        $pw=$this->input->post('txtpassword');
        $this->load->model('Home_model');
        $check_login=$this->Home_model->logindata($un,$pw);
        if($check_login<>'')
        {
            if($check_login[0]['status']==1){
                if($check_login[0]['usertype']==1){
                    $data = array(
                        'logged_in'  =>  TRUE,
                        'username' => $check_login[0]['username'],
                        'usertype' => $check_login[0]['usertype'],
                        'userid' => $check_login[0]['id'],
                        'roleName' => $check_login[0]['role_name']
                    );
                    $this->session->set_userdata($data);
                    redirect('/');
                }
                elseif($check_login[0]['usertype']==2){
                    $data = array(
                        'logged_in'  =>  TRUE,
                        'username' => $check_login[0]['username'],
                        'usertype' => $check_login[0]['usertype'],
                        'userid' => $check_login[0]['id'],
                        'roleName' => $check_login[0]['role_name']
                    );
                    $this->session->set_userdata($data);
                    redirect('/');
                }
                else{
                    $this->session->set_flashdata('login_error', 'Sorry, you cant login right now.', 300);
                    redirect(base_url().'login');
                }
                
            }
            else{
                $this->session->set_flashdata('login_error', 'Sorry, your account is blocked.', 300);
                redirect(base_url().'login');
            }
            
        }
        else{
            $this->session->set_flashdata('login_error', 'Please check your username or password and try again.', 300);
            redirect(base_url().'login');
        }
    }

    public function logout()
    {
        $this->session->sess_destroy();
        redirect(base_url().'login');
    }

    public function demo()
    {
        $this->load->view('admin/header');
        $this->load->view('admin/demo');
        $this->load->view('admin/footer');
                
    }
    public function fetch_data() {
        $updated_data = $this->AccessLog_model->get_data();

        echo json_encode($updated_data);
    }
    public function fetch_quickdata() {
        $searchKey = $_GET['searchKey'];
        $updated_data = $this->AccessLog_model->get_searchKeyData($searchKey);

        echo json_encode($updated_data);
    }
    public function fetch_Alldata() {
        $period = $_GET['period'];
            $start_date = $_GET['start_date'];
            $end_date = $_GET['end_date'];
            $updated_data = $this->AccessLog_model->get_Alldata($period,$start_date,$end_date);

        echo json_encode($updated_data);
    }
    public function advance_search() {
        $formData = $this->input->post();
        $updated_data = $this->AccessLog_model->get_searchResult($formData);
        echo json_encode($updated_data);exit;
    }

    

    public function search_results()
	{
        
        $data['profile']=$this->Home_model->select_profile();
        $data['allpermission']=$this->Staff_model->select_staff_byID($this->session->userdata('userid'));
        $permissions = explode(",", $data['allpermission']['0']['permission']);
        $data['permissions'] = $permissions;
        $data['vehcle']=$this->Vehicle_model->select_vehicle();
                $data['vehicleType']=$this->Home_model->select_vehicleType();
                $data['rfid']=$this->Rfid_model->select_rfid();
                $data['policy']=$this->Policy_model->select_policy();
                $data['transportor']=$this->Transportor_model->select_transportor();
                $data['driver']=$this->Driver_model->select_driver();


                $this->load_common_data();
                $this->load->view('admin/search_result');
                $this->load->view('admin/footer');
                //redirect('admin/search_result?query=' . urlencode($searchResults));
            
            }


            

}
