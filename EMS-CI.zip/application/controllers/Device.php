<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Device extends MY_Controller {

    function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('logged_in'))
        { 
            redirect(base_url().'login');   
        }

       
    }

    public function index()
    {
        $this->load_common_data();
        // $permissions = [
        //     ['permission_id' => '3', 'type' => 'view']
        // ];
        // if ($this->check_permissions($permissions))
        // {
        $this->load->view('admin/add-device');
        $this->load->view('admin/footer');
        // }else{
        //     redirect(base_url());   
        // }
    }

    public function manage()
    {
        $data['content']=$this->Device_model->select_device();
        $this->load_common_data();
        $permissions = [
            ['permission_id' => '3', 'type' => 'manage']
        ];
        if ($this->check_permissions($permissions))
        {    
        $this->load->view('admin/manage-device',$data);
        $this->load->view('admin/footer');
        }else{
            redirect(base_url());   
        }
    }

    public function insert()
    {
        $this->form_validation->set_rules('txtdevice', 'Device Type', 'required');
        $this->form_validation->set_rules('status', 'Status', 'required');
    
        $device=$this->input->post('txtdevice');
        $status=$this->input->post('status');
        $added=$this->session->userdata('userid');
        $insert_device = array(
            'device_name'=>$device,
            'status'=>$status,
            'created_by'=>$added,
            'created_date'=>date("Y-m-d")
           );    
        if($this->form_validation->run() !== false)
        {
            $data=$this->Device_model->insert_device($insert_device);
            if($data==true)
            {
                $this->session->set_flashdata('success', "New device Added Succesfully"); 
            }else{
                $this->session->set_flashdata('error', "Sorry, New device Adding Failed.");
            }
           redirect($_SERVER['HTTP_REFERER']);
        }else{
            redirect($_SERVER['HTTP_REFERER']);
            return false;
        }
    }

    public function update()
    {
        $this->form_validation->set_rules('txtdevice', 'Device Type', 'required');
        $this->form_validation->set_rules('status', 'Status', 'required');
    
        $added=$this->session->userdata('userid');


        $id=$this->input->post('txtid');
        $device=$this->input->post('txtdevice');
        $status=$this->input->post('status');

        $update_device = array(
            'device_name'=>$device,
            'status'=>$status,
            'updated_by'=>$added,
            'updated_date'=>date("Y-m-d")
           );    
   if($this->form_validation->run() !== false)
        {
            
        $this->Device_model->update_device($update_device ,$id);
        if($this->db->affected_rows() > 0)
        {
            $this->session->set_flashdata('success', "device Updated Succesfully"); 
        }else{
            $this->session->set_flashdata('error', "Sorry, device Update Failed.");
        }
        redirect(base_url()."manage-device");
    }else{
        redirect($_SERVER['HTTP_REFERER']);
        return false;
  
        }
    }


    function edit($id)
    {
        $data['content']=$this->Device_model->select_device_byID($id);
        // $this->load_common_data();
        // $permissions = [
        //     ['permission_id' => '3', 'type' => 'edit']
        // ];
        // if ($this->check_permissions($permissions))
        // {
            $this->load_common_data();
            $this->load->view('admin/edit-device',$data);
            $this->load->view('admin/footer');
        // }else{
        //     redirect(base_url()); 
        // }
    }


    function delete($id)
    {
        $data=$this->Device_model->delete_device($id);
        if($this->db->affected_rows() > 0)
        {
            $this->session->set_flashdata('success', "device Deleted Succesfully"); 
        }else{
            $this->session->set_flashdata('error', "Sorry, device Delete Failed.");
        }
        redirect($_SERVER['HTTP_REFERER']);
    }



}
    