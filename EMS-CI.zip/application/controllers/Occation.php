<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Occation extends MY_Controller {

    function __construct()
    {
        parent::__construct();
        if ( ! $this->session->userdata('logged_in'))
        { 
            redirect(base_url().'login');
        }
    }

    public function index()
    {
        $this->load_common_data();
        $this->load->view('admin/add-occation');
        $this->load->view('admin/footer');
    }

    public function manage()
    {
        $data['content']=$this->Occation_model->select_occation();
        $this->load_common_data();
        $this->load->view('admin/manage-occation',$data);
        $this->load->view('admin/footer');
    }

    public function insert()
    {
        $this->form_validation->set_rules('txtoccation', 'Name', 'required');
        $this->form_validation->set_rules('status', 'Status', 'required');
       
        $occation=$this->input->post('txtoccation');
        $status=$this->input->post('status');
        if($this->form_validation->run() !== false)
        {
            $data=$this->Occation_model->insert_occation(array('occation_name'=>$occation,'status'=>$status));
            if($data==true)
            {
                $this->session->set_flashdata('success', "New occation Added Succesfully"); 
            }else{
                $this->session->set_flashdata('error', "Sorry, New occation Adding Failed.");
            }
            redirect($_SERVER['HTTP_REFERER']);
        }else{
            $this->index();
            return false;

        } 
    }

    public function update()
    {
        $id=$this->input->post('txtid');
        $this->form_validation->set_rules('txtoccation', 'Name', 'required');
        $this->form_validation->set_rules('status', 'Status', 'required');
       
        $occation=$this->input->post('txtoccation');
        $status=$this->input->post('status');
        if($this->form_validation->run() !== false)
        {
            
            $data=$this->Occation_model->update_occation(array('occation_name'=>$occation,'status'=>$status),$id);
            if($this->db->affected_rows() > 0)
            {
                $this->session->set_flashdata('success', "occation Updated Succesfully"); 
            }else{
                $this->session->set_flashdata('error', "Sorry, occation Update Failed.");
            }
            redirect(base_url()."manage-occation");
        }else{
            $this->edit($id);
            return false;

        }
    }


    function edit($id)
    {
        $data['content']=$this->Occation_model->select_occation_byID($id);
        $this->load_common_data();
        $this->load->view('admin/edit-occation',$data);
        $this->load->view('admin/footer');
    }


    function delete($id)
    {
        $data=$this->Occation_model->delete_occation($id);
        if($this->db->affected_rows() > 0)
        {
            $this->session->set_flashdata('success', "occation Deleted Succesfully"); 
        }else{
            $this->session->set_flashdata('error', "Sorry, occation Delete Failed.");
        }
        redirect($_SERVER['HTTP_REFERER']);
    }



}
