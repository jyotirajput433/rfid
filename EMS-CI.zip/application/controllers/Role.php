<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Role extends MY_Controller {

    function __construct()
    {
        parent::__construct();
        if ( ! $this->session->userdata('logged_in'))
        { 
            redirect(base_url().'login');
        }
    }

    public function index()
    {
        $data['role']=$this->Role_model->select_role();
      //  $data['country']=$this->Home_model->select_countries();
        $this->load_common_data();
        $this->load->view('admin/add-role',$data);
        $this->load->view('admin/footer');
    }

    public function manage()
    {
         $data['role']=$this->Role_model->select_role();
        $this->load_common_data();
        $this->load->view('admin/manage-role',$data);
        $this->load->view('admin/footer');
    }

    public function insert()
    {
        $this->form_validation->set_rules('driver_name', 'Name', 'required');
        
        
        $number=$this->input->post('contact');
        $name=$this->input->post('driver_name');
        $adhar=$this->input->post('adhar_id');
        $t_id=$this->input->post('transportor_id');
        $status=$this->input->post('status');
       
        
        $added=$this->session->userdata('userid');
        $createdTime = date("y-m-d");

        if($this->form_validation->run() !== false)
        {

            $this->load->library('image_lib');
            $config['upload_path']= 'uploads/profile-pic/';
            $config['allowed_types'] ='gif|jpg|png|jpeg';
            $this->load->library('upload', $config);
            if ( ! $this->upload->do_upload('filephoto'))
            {
                $image='default-pic.jpg';
            }
            else
            {
                $image_data =   $this->upload->data();

                $configer =  array(
                  'image_library'   => 'gd2',
                  'source_image'    =>  $image_data['full_path'],
                  'maintain_ratio'  =>  TRUE,
                  'width'           =>  150,
                  'height'          =>  150,
                  'quality'         =>  50
                );
                $this->image_lib->clear();
                $this->image_lib->initialize($configer);
                $this->image_lib->resize();
                
                $image=$image_data['file_name'];
            }


            $insert_driverData = array(
                'driver_name'=>$name,
                'contact'=>$number,
                'photo'=>$image,
                'status'=>$status,
                'transportor_id'=>$t_id,
                'adhar_id'=>$adhar,
                'created_by'=>$added,
                'created_date'=>$createdTime,
               );
            $data=$this->Driver_model->insert_driver($insert_driverData);
          
            if($data==true)
            {
                
                $this->session->set_flashdata('success', "New Staff Added Succesfully"); 
            }else{
                $this->session->set_flashdata('error', "Sorry, New Staff Adding Failed.");
            }
            redirect($_SERVER['HTTP_REFERER']);
        }
        else{
            $this->index();
            return false;

        } 
    }

    public function update()
    {
        $this->load->helper('form');
        $this->form_validation->set_rules('txtname', 'Full Name', 'required');
        $this->form_validation->set_rules('slcgender', 'Gender', 'required');
        $this->form_validation->set_rules('slcdepartment', 'Department', 'required');
        $this->form_validation->set_rules('txtemail', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('txtmobile', 'Mobile Number ', 'required|regex_match[/^[0-9]{10}$/]');
        $this->form_validation->set_rules('txtdob', 'Date of Birth', 'required');
        $this->form_validation->set_rules('txtdoj', 'Date of Joining', 'required');
        $this->form_validation->set_rules('txtcity', 'City', 'required');
        $this->form_validation->set_rules('txtstate', 'State', 'required');
        $this->form_validation->set_rules('slccountry', 'Country', 'required');
        
        $id=$this->input->post('txtid');
        $name=$this->input->post('txtname');
        $gender=$this->input->post('slcgender');
        $department=$this->input->post('slcdepartment');
        $email=$this->input->post('txtemail');
        $mobile=$this->input->post('txtmobile');
        $dob=$this->input->post('txtdob');
        $doj=$this->input->post('txtdoj');
        $city=$this->input->post('txtcity');
        $state=$this->input->post('txtstate');
        $country=$this->input->post('slccountry');
        $address=$this->input->post('txtaddress');

        if($this->form_validation->run() !== false)
        {
            $this->load->library('image_lib');
            $config['upload_path']= 'uploads/profile-pic/';
            $config['allowed_types'] ='gif|jpg|png|jpeg';
            $this->load->library('upload', $config);
            if ( ! $this->upload->do_upload('filephoto'))
            {
                $data=$this->Staff_model->update_staff(array('staff_name'=>$name,'gender'=>$gender,'email'=>$email,'mobile'=>$mobile,'dob'=>$dob,'doj'=>$doj,'address'=>$address,'city'=>$city,'state'=>$state,'country'=>$country,'department_id'=>$department),$id);
            }
            else
            {
                $image_data =   $this->upload->data();

                $configer =  array(
                  'image_library'   => 'gd2',
                  'source_image'    =>  $image_data['full_path'],
                  'maintain_ratio'  =>  TRUE,
                  'width'           =>  150,
                  'height'          =>  150,
                  'quality'         =>  50
                );
                $this->image_lib->clear();
                $this->image_lib->initialize($configer);
                $this->image_lib->resize();

                $data=$this->Staff_model->update_staff(array('staff_name'=>$name,'gender'=>$gender,'email'=>$email,'mobile'=>$mobile,'dob'=>$dob,'doj'=>$doj,'address'=>$address,'city'=>$city,'state'=>$state,'country'=>$country,'department_id'=>$department,'pic'=>$image_data['file_name'],'added_by'=>$added),$id);
            }
            
            if($this->db->affected_rows() > 0)
            {
                $this->session->set_flashdata('success', "Staff Updated Succesfully"); 
            }else{
                $this->session->set_flashdata('error', "Sorry, Staff Updated Failed.");
            }
            redirect(base_url()."manage-staff");
        }
        else{
            $this->index();
            return false;

        } 
    }


    function edit($id)
    {
        $data['department']=$this->Department_model->select_departments();
        $data['country']=$this->Home_model->select_countries();
        $data['content']=$this->Staff_model->select_staff_byID($id);
        $this->load_common_data();
        $this->load->view('admin/edit-staff',$data);
        $this->load->view('admin/footer');
    }


    function delete($id)
    {
        $this->Home_model->delete_login_byID($id);
        $data=$this->Staff_model->delete_staff($id);
        if($this->db->affected_rows() > 0)
        {
            $this->session->set_flashdata('success', "Staff Deleted Succesfully"); 
        }else{
            $this->session->set_flashdata('error', "Sorry, Staff Delete Failed.");
        }
        redirect($_SERVER['HTTP_REFERER']);
    }

    public function roleaccess($role_id)
    {
        $data['profile']=$this->Home_model->select_profile();

        $data['title'] = 'Access Authority';
        $data['user'] = $this->db->get_where('login_tbl', ['id' => $this->session->userdata('userid')])->row_array();
        $data['menu'] = $this->Home_model->select_permission();
        $data['role'] = $this->db->get_where('role_tbl', ['id' => $role_id])->row_array();
        $this->db->where('id !=', 1);
        
        $this->load_common_data();
        $this->load->view('admin/role-access',$data);
        $this->load->view('admin/footer');
            
    }

        // change access
        public function changeaccess()
        {
            $menu_id = $this->input->post('menuId');
            $role_id = $this->input->post('roleId');
            $data = [
                'role_id' => $role_id,
                'permission_id' => $menu_id
            ];
    
            $result = $this->db->get_where('role_access_tbl', $data);
    
            if ($result->num_rows() < 1) {
                $this->db->insert('role_access_tbl', $data);
            } else {
                $this->db->delete('role_access_tbl', $data);
            }
    
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
            Access has been changed!</div>');
        }
    
    
        public function changeaccessView()
        {
            $menu_id = $this->input->post('menuId');
            $role_id = $this->input->post('roleId');
            $view = $this->input->post('value');
            $data = [
                'role_id' => $role_id,
                'permission_id' => $menu_id
            ];
    
            $dataupdate = [
                'View'=> $view
            ];
    
            $result = $this->db->get_where('role_access_tbl',$data);
    
            if ($result->num_rows() > 0) {
                $this->db->update('role_access_tbl',$dataupdate ,$data);
            }   
    
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
            Access has been changed!</div>');
        }
    
        public function changeaccessEdit()
        {
            $menu_id = $this->input->post('menuId');
            $role_id = $this->input->post('roleId');
            $edit = $this->input->post('value');
     
            $data = [
                'role_id' => $role_id,
                'permission_id' => $menu_id,
            ];
            $dataupdate = [
                'Edit'=> $edit
            ];
    
            $result = $this->db->get_where('role_access_tbl', $data);
    
            if ($result->num_rows() > 0) {
                $this->db->update('role_access_tbl', $dataupdate,$data);
            }
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
            Access has been changed!</div>');
        }
    
        public function changeaccessDelete()
        {
            $menu_id = $this->input->post('menuId');
            $role_id = $this->input->post('roleId');
            $delete = $this->input->post('value');
    
            $data = [
                'role_id' => $role_id,
                'permission_id' => $menu_id
            ];
            $dataupdate = [
                'Delete'=> $delete
            ];
            $result = $this->db->get_where('role_access_tbl', $data);
    
            if ($result->num_rows() > 0) {
                $this->db->update('role_access_tbl', $dataupdate,$data);
            } 
    
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
            Access has been changed!</div>');
        }
        


}
