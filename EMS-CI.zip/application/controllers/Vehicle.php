<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Vehicle extends MY_Controller {

    function __construct()
    {
        parent::__construct();
        if ( ! $this->session->userdata('logged_in'))
        { 
            redirect(base_url().'login');
        }
    }

    public function index()
    {
        $data['vehcle']=$this->Vehicle_model->select_vehicle();
        $data['vehicleType']=$this->Home_model->select_vehicleType();
        $data['rfid']=$this->Rfid_model->select_rfid();
        $data['policy']=$this->Policy_model->select_policy();
        $data['transportor']=$this->Transportor_model->select_transportor();
        $data['driver']=$this->Driver_model->select_driver();
        $this->load_common_data();
        $this->load->view('admin/add-vehicle',$data);
        $this->load->view('admin/footer');
    }

    public function manage()
    {
        $data['content']=$this->Vehicle_model->select_vehicle();
        $this->load_common_data();
        $this->load->view('admin/manage-vehicle',$data);
        $this->load->view('admin/footer');
    }

    public function insert()
    {
        $this->form_validation->set_rules('vehicle_type', 'Vehicle type', 'required');
        $this->form_validation->set_rules('number', 'Vehicle Number', 'required');
        $this->form_validation->set_rules('color', 'Color', 'required');
        $this->form_validation->set_rules('rfid_tag', 'RFID Tag', 'required');
        $this->form_validation->set_rules('vehicle_policy', 'Policy', 'required');
        $this->form_validation->set_rules('is_allowed', 'Allowed', 'required');
        $this->form_validation->set_rules('parmit_valid_till', 'Permit Validity', 'required');
        $this->form_validation->set_rules('owner', 'Owner', 'required');
        $this->form_validation->set_rules('driver_id', 'Driver', 'required');
        $this->form_validation->set_rules('is_valid', 'Validity', 'required');
        
        
        $vehicle_type=$this->input->post('vehicle_type');
        $number=$this->input->post('number');
        $color=$this->input->post('color');
        $rfid_tag=$this->input->post('rfid_tag');
        $vehicle_policy=$this->input->post('vehicle_policy');
        $is_allowed=$this->input->post('is_allowed');
        $permit_valid_till=$this->input->post('parmit_valid_till');
        $owner=$this->input->post('owner');
        $driver_id=$this->input->post('driver_id');
        $is_valid=$this->input->post('is_valid');
        $added=$this->session->userdata('userid');
        $createdTime = date("y-m-d");
        if($this->form_validation->run() !== false)
        {

            $this->load->library('image_lib');
            $config['upload_path']= 'uploads/profile-pic/';
            $config['allowed_types'] ='gif|jpg|png|jpeg';
            $this->load->library('upload', $config);
            if ( ! $this->upload->do_upload('vehiclephoto'))
            {
                $image='default-pic.jpg';
            }
            else
            {
                $image_data =   $this->upload->data();

                $configer =  array(
                  'image_library'   => 'gd2',
                  'source_image'    =>  $image_data['full_path'],
                  'maintain_ratio'  =>  TRUE,
                  'width'           =>  150,
                  'height'          =>  150,
                  'quality'         =>  50
                );
                $this->image_lib->clear();
                $this->image_lib->initialize($configer);
                $this->image_lib->resize();
                
                $image=$image_data['file_name'];
            }

            

            
            $insert_vehicleData = array(
                'vehicle_type' => $vehicle_type,
                'number' => $number,
                'color' => $color,
                'rfid_tag' => $rfid_tag,
                'vehicle_policy' => $vehicle_policy,
                'is_allowed' => $is_allowed,
                'permit_valid_till' => $permit_valid_till,
                'owner' => $owner,
                'driver_id' => $driver_id,
                'is_valid' => $is_valid,
                'vehicle_photo' => $is_valid,
                'created_by'=>$added,
                'created_date'=>$createdTime,
               );
            $data=$this->Vehicle_model->insert_vehicle($insert_vehicleData);
          
            if($data==true)
            {       
                $this->session->set_flashdata('success', "New Staff Added Succesfully"); 
            }else{
                $this->session->set_flashdata('error', "Sorry, New Staff Adding Failed.");
            }
            redirect($_SERVER['HTTP_REFERER']);
        }
        else{
            $this->index();
            return false;

        } 
    }

    public function update()
    {
        $this->load->helper('form');

        $this->form_validation->set_rules('vehicle_type', 'Vehicle type', 'required');
        $this->form_validation->set_rules('number', 'Vehicle Number', 'required');
        $this->form_validation->set_rules('color', 'Color', 'required');
        $this->form_validation->set_rules('rfid_tag', 'RFID Tag', 'required');
        $this->form_validation->set_rules('vehicle_policy', 'Policy', 'required');
        $this->form_validation->set_rules('is_allowed', 'Allowed', 'required');
        $this->form_validation->set_rules('parmit_valid_till', 'Permit Validity', 'required');
        $this->form_validation->set_rules('owner', 'Owner', 'required');
        $this->form_validation->set_rules('driver_id', 'Driver', 'required');
        $this->form_validation->set_rules('is_valid', 'Validity', 'required');
        
        
        $vehicle_type=$this->input->post('vehicle_type');
        $number=$this->input->post('number');
        $color=$this->input->post('color');
        $rfid_tag=$this->input->post('rfid_tag');
        $vehicle_policy=$this->input->post('vehicle_policy');
        $is_allowed=$this->input->post('is_allowed');
        $permit_valid_till=$this->input->post('parmit_valid_till');
        $owner=$this->input->post('owner');
        $driver_id=$this->input->post('driver_id');
        $is_valid=$this->input->post('is_valid');
        $added=$this->session->userdata('userid');
        $createdTime = date("y-m-d");
        if($this->form_validation->run() !== false)
        {
            $this->load->library('image_lib');
            $config['upload_path']= 'uploads/profile-pic/';
            $config['allowed_types'] ='gif|jpg|png|jpeg';
            $this->load->library('upload', $config);
            if ( ! $this->upload->do_upload('vehiclephoto'))
            {
                $image='default-pic.jpg';
                
            }
            else
            {
                $image_data =   $this->upload->data();

                $configer =  array(
                  'image_library'   => 'gd2',
                  'source_image'    =>  $image_data['full_path'],
                  'maintain_ratio'  =>  TRUE,
                  'width'           =>  150,
                  'height'          =>  150,
                  'quality'         =>  50
                );
                $this->image_lib->clear();
                $this->image_lib->initialize($configer);
                $this->image_lib->resize();
                
                $image=$image_data['file_name'];
            }

            

                $update_vehicleData = array(
                    'vehicle_type' => $vehicle_type,
                    'number' => $number,
                    'color' => $color,
                    'rfid_tag' => $rfid_tag,
                    'vehicle_policy' => $vehicle_policy,
                    'is_allowed' => $is_allowed,
                    'permit_valid_till' => $permit_valid_till,
                    'owner' => $owner,
                    'driver_id' => $driver_id,
                    'is_valid' => $is_valid,
                    'vehicle_photo' => $image,
                    'created_by'=>$added,
                    'created_date'=>$createdTime,
                   );
       
                $data=$this->Vehicle_model->update_vehicle($update_vehicleData,$id);
            
            if($this->db->affected_rows() > 0)
            {
                $this->session->set_flashdata('success', "Staff Updated Succesfully"); 
            }else{
                $this->session->set_flashdata('error', "Sorry, Staff Updated Failed.");
            }
            redirect(base_url()."manage-vehicle");
        }
    
        else{
            redirect($_SERVER['HTTP_REFERER']);
            return false;

        } 
    }


    function edit($id)
    {
        $data['content']=$this->Vehicle_model->select_vehicle_byID($id);
        $data['vehcle']=$this->Vehicle_model->select_vehicle();
        $data['vehicleType']=$this->Home_model->select_vehicleType();
        $data['rfid']=$this->Rfid_model->select_rfid();
        $data['policy']=$this->Policy_model->select_policy();
        $data['transportor']=$this->Transportor_model->select_transportor();
        $data['driver']=$this->Driver_model->select_driver();
         $this->load_common_data();
        $this->load->view('admin/edit-vehicle',$data);
        $this->load->view('admin/footer');
    }


    function delete($id)
    {
        $this->Home_model->delete_login_byID($id);
        $data=$this->Vehicle_model->delete_vehicle($id);
        if($this->db->affected_rows() > 0)
        {
            $this->session->set_flashdata('success', "Staff Deleted Succesfully"); 
        }else{
            $this->session->set_flashdata('error', "Sorry, Staff Delete Failed.");
        }
        redirect($_SERVER['HTTP_REFERER']);
    }

    



}
