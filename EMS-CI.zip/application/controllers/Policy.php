<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Policy extends MY_Controller {

    function __construct()
    {
        parent::__construct();
        if ( ! $this->session->userdata('logged_in'))
        { 
            redirect(base_url().'login');
        }
    }

    public function index()
    {
        $data['department']=$this->Department_model->select_departments();
        $data['country']=$this->Home_model->select_countries();
        $this->load_common_data();
        $this->load->view('admin/add-policy',$data);
        $this->load->view('admin/footer');
    }

    public function manage()
    {
        $data['content']=$this->Policy_model->select_policy();
        $this->load_common_data();
        $this->load->view('admin/manage-policy',$data);
        $this->load->view('admin/footer');
    }

    public function insert()
    {
        $this->form_validation->set_rules('policy_name', 'Policy Name', 'required'); 
        $this->form_validation->set_rules('access_type', 'Access Type', 'required'); 
        $this->form_validation->set_rules('from_time', 'From-time', 'required'); 
        $this->form_validation->set_rules('to_time', 'To-time', 'required'); 
        $this->form_validation->set_rules('all_days', 'All Days', 'required'); 
        $this->form_validation->set_rules('allowed_days', 'Alloowed Days', 'required'); 
        $this->form_validation->set_rules('special_days', 'Special Days', 'required'); 


//        $id=$this->input->post('txtid');
        $policy_name = $this->input->post('policy_name');
        $access_type = $this->input->post('access_type');
        $from_time = $this->input->post('from_time');
        $to_time = $this->input->post('to_time');
        $all_days = $this->input->post('all_days');
        $allowed_days = $this->input->post('allowed_days');
        $special_days = $this->input->post('special_days');
        $added=$this->session->userdata('userid');

        
        if($this->form_validation->run() !== false)
        {

            $insert_policyData =array(
                'policy_name' => $policy_name,
                'access_type' => $access_type,
                'from_time' => $from_time,
                'to_time' => $to_time,
                'all_days' => $all_days,
                'allowed_days' => $allowed_days,
                'special_days' => $special_days,
                'status' => 1,
                'created_by' => $added,
                'created_date'=>date("Y-m-d")
            );  
            
            
            $data=$this->Policy_model->insert_policy($insert_policyData);
            
            if($data==true)
            {
                
                $this->session->set_flashdata('success', "New policy Added Succesfully"); 
            }else{
                $this->session->set_flashdata('error', "Sorry, New policy Adding Failed.");
            }
            redirect($_SERVER['HTTP_REFERER']);
        }
        else{
            $this->index();
            return false;

        } 
    }

    public function update()
    {
        $this->load->helper('form');
        $this->form_validation->set_rules('policy_name', 'Policy Name', 'required'); 
        $this->form_validation->set_rules('access_type', 'Access Type', 'required'); 
        $this->form_validation->set_rules('from_time', 'From-time', 'required'); 
        $this->form_validation->set_rules('to_time', 'To-time', 'required'); 
        $this->form_validation->set_rules('all_days', 'All Days', 'required'); 
        $this->form_validation->set_rules('allowed_days', 'Alloowed Days', 'required'); 
        $this->form_validation->set_rules('special_days', 'Special Days', 'required'); 


        $id=$this->input->post('txtid');
        $policy_name = $this->input->post('policy_name');
        $access_type = $this->input->post('access_type');
        $from_time = $this->input->post('from_time');
        $to_time = $this->input->post('to_time');
        $all_days = $this->input->post('all_days');
        $allowed_days = $this->input->post('allowed_days');
        $special_days = $this->input->post('special_days');
        $added=$this->session->userdata('userid');

        
        if($this->form_validation->run() !== false)
        {

            $update_policyData =array(
                'policy_name' => $policy_name,
                'access_type' => $access_type,
                'from_time' => $from_time,
                'to_time' => $to_time,
                'all_days' => $all_days,
                'allowed_days' => $allowed_days,
                'special_days' => $special_days,
                'updated_by' => $added,
                'updated_date'=>date("Y-m-d")
            );  
            $data=$this->Policy_model->update_policy($update_policyData,$id);
    
            
            if($this->db->affected_rows() > 0)
            {
                $this->session->set_flashdata('success', "policy Updated Succesfully"); 
            }else{
                $this->session->set_flashdata('error', "Sorry, policy Updated Failed.");
            }
            redirect(base_url()."manage-policy");
        }
        else{
            $this->edit($id);
            return false;

        } 
    }


    function edit($id)
    {
        $data['department']=$this->Department_model->select_departments();
        $data['country']=$this->Home_model->select_countries();
        $data['content']=$this->Policy_model->select_policy_byID($id);
        $this->load_common_data();
        $this->load->view('admin/edit-policy',$data);
        $this->load->view('admin/footer');
    }


    function delete($id)
    {
        $this->Home_model->delete_login_byID($id);
        $data=$this->Policy_model->delete_policy($id);
        if($this->db->affected_rows() > 0)
        {
            $this->session->set_flashdata('success', "policy Deleted Succesfully"); 
        }else{
            $this->session->set_flashdata('error', "Sorry, policy Delete Failed.");
        }
        redirect($_SERVER['HTTP_REFERER']);
    }

    



}
