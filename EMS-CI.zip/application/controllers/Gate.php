<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Gate extends MY_Controller {

    function __construct()
    {
        parent::__construct();
        if ( ! $this->session->userdata('logged_in'))
        { 
            redirect(base_url().'login');
        }
    }

    public function index()
    {
        $this->load_common_data();
        $this->load->view('admin/add-gate');
        $this->load->view('admin/footer');
    }

    public function manage()
    {
        $data['content']=$this->Gate_model->select_gate();
        $this->load_common_data();
        $this->load->view('admin/manage-gate',$data);
        $this->load->view('admin/footer');
    }

    public function insert()
    {
        $this->form_validation->set_rules('txtgate', 'Gate', 'required'); 
        $this->form_validation->set_rules('status', 'Status', 'required'); 
     
        $gate=$this->input->post('txtgate');
        $status=$this->input->post('status');
        $added=$this->session->userdata('userid');

        if($this->form_validation->run() !== false)
        {

            $insert_Data =array(
                'gate_name' => $gate,
                'status' => $status,
                'created_by' => $added,
                'created_date'=>date("Y-m-d")
            );  
                        
            $data=$this->Gate_model->insert_gate($insert_Data);
            if($data==true)
            {
                $this->session->set_flashdata('success', "New gate Added Succesfully"); 
            }else{
                $this->session->set_flashdata('error', "Sorry, New gate Adding Failed.");
            }
            redirect($_SERVER['HTTP_REFERER']);
        }else{
            $this->index();
            return false;
        }
    }

    public function update()
    {
        $id=$this->input->post('txtid');
        $gate=$this->input->post('txtgate');
        $data=$this->Gate_model->update_gate(array('gate_name'=>$gate),$id);
        if($this->db->affected_rows() > 0)
        {
            $this->session->set_flashdata('success', "gate Updated Succesfully"); 
        }else{
            $this->session->set_flashdata('error', "Sorry, gate Update Failed.");
        }
        redirect(base_url()."manage-gate");
    }


    function edit($id)
    {
        $data['content']=$this->Gate_model->select_gate_byID($id);
        $this->load_common_data();
        $this->load->view('admin/edit-gate',$data);
        $this->load->view('admin/footer');
    }


    function delete($id)
    {
        $data=$this->Gate_model->delete_gate($id);
        if($this->db->affected_rows() > 0)
        {
            $this->session->set_flashdata('success', "gate Deleted Succesfully"); 
        }else{
            $this->session->set_flashdata('error', "Sorry, gate Delete Failed.");
        }
        redirect($_SERVER['HTTP_REFERER']);
    }



}
