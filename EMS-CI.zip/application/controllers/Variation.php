<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Variation extends MY_Controller {

    function __construct()
    {
        parent::__construct();
        if ( ! $this->session->userdata('logged_in'))
        { 
            redirect(base_url().'login');
        }
    }

    public function index()
    {
        $this->load_common_data();
        $this->load->view('admin/add-variation');
        $this->load->view('admin/footer');
    }

    public function manage()
    {
        $data['content']=$this->Variation_model->select_variation();
        $this->load_common_data();
        $this->load->view('admin/manage-variation',$data);
        $this->load->view('admin/footer');
    }

    public function insert()
    {
        $this->form_validation->set_rules('txtvariation', 'Reason', 'required');
      
        $variation=$this->input->post('txtvariation');
        $data=$this->Variation_model->insert_variation(array('variation_name'=>$variation));
        if($this->form_validation->run() !== false)
                {
            if($data==true)
            {
                $this->session->set_flashdata('success', "New variation Added Succesfully"); 
            }else{
                $this->session->set_flashdata('error', "Sorry, New variation Adding Failed.");
            }
            redirect($_SERVER['HTTP_REFERER']);
        }else{
        $this->index();
        return false;
    }
    }

    public function update()
    {
        $this->form_validation->set_rules('txtvariation', 'Reason', 'required');
      
        $id=$this->input->post('txtid');
        $variation=$this->input->post('txtvariation');
        if($this->form_validation->run() !== false)
        {
            $data=$this->Variation_model->update_variation(array('variation_name'=>$variation),$id);
            if($this->db->affected_rows() > 0)
            {
                $this->session->set_flashdata('success', "variation Updated Succesfully"); 
            }else{
                $this->session->set_flashdata('error', "Sorry, variation Update Failed.");
            }
            redirect(base_url()."manage-variation");
        }else{
            redirect($_SERVER['HTTP_REFERER']);
            return false;
        }
            
    }


    function edit($id)
    {
        $data['content']=$this->Variation_model->select_variation_byID($id);
        $this->load_common_data();
        $this->load->view('admin/edit-variation',$data);
        $this->load->view('admin/footer');
    }


    function delete($id)
    {
        $data=$this->Variation_model->delete_variation($id);
        if($this->db->affected_rows() > 0)
        {
            $this->session->set_flashdata('success', "variation Deleted Succesfully"); 
        }else{
            $this->session->set_flashdata('error', "Sorry, variation Delete Failed.");
        }
        redirect($_SERVER['HTTP_REFERER']);
    }



}
